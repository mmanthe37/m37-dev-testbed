import { useWallet } from "./useWallet";
import { useApi } from "./useApi";

export function useSmartWallet() {
  const { address, provider } = useWallet();
  const api = useApi();

  // Example: programmable policy management
  async function setPolicy(policy: object) {
    return api.post("/omniagent/set-policy", { address, policy });
  }

  // Example: fund smart wallet
  async function fund(amount: string) {
    // Could be a contract interaction or backend call
    return api.post("/omniagent/fund", { address, amount });
  }

  return { setPolicy, fund };
}