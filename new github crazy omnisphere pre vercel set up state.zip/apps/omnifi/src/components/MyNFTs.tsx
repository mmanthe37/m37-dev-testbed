import React, { useEffect, useState } from "react";
import { useApi } from "../hooks/useApi";

export default function MyNFTs() {
  const api = useApi();
  const [nfts, setNFTs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const { data } = await api.get("/omnifi/my-nfts");
      setNFTs(data || []);
      setLoading(false);
    })();
  }, [api]);

  if (loading) return <div className="text-accentPurple">Loading your NFTs...</div>;
  if (!nfts.length) return <div className="text-textSecondary">You haven't minted any NFTs yet.</div>;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
      {nfts.map((nft, i) => (
        <div key={i} className="bg-card rounded-xl p-5 shadow-omnisphere flex flex-col items-center">
          <img src={nft.imageUrl} alt={nft.title} className="w-full h-48 object-cover rounded-lg mb-3" />
          <div className="font-orbitron font-bold text-lg text-accentBlue">{nft.title}</div>
          <div className="text-textSecondary mb-2">{nft.description}</div>
          <div className="text-xs text-accentPurple">Token ID: {nft.tokenId}</div>
        </div>
      ))}
    </div>
  );
}