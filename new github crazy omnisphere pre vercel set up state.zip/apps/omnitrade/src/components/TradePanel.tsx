import React, { useState } from "react";
import { useDexAggregator } from "../hooks/useDexAggregator";
import { useGaslessTrade } from "../hooks/useGaslessTrade";
import { buildSwapUserOp } from "../utils/userOp";
import { useWallet } from "../hooks/useWallet";

export default function TradePanel({ symbol }: { symbol: string }) {
  const { address, provider } = useWallet();
  const aggregator = useDexAggregator();
  const { submitGaslessTrade } = useGaslessTrade();
  const [amount, setAmount] = useState("");
  const [status, setStatus] = useState("");

  async function onTrade() {
    setStatus("Finding best route...");
    await aggregator.findRoute({ from: "ETH", to: "USDC", amount });
    setStatus("Building UserOp...");
    const userOp = buildSwapUserOp({
      walletAddress: address,
      dexRouter: aggregator.route?.to, // e.g. Uniswap router address
      swapData: aggregator.route?.data, // Calldata for swap
      entryPoint: "0xEntryPointAddress"
    });
    setStatus("Submitting gasless trade...");
    const result = await submitGaslessTrade(userOp);
    setStatus(result.success ? "Trade sent gaslessly!" : "Trade failed");
  }

  return (
    <div>
      <input value={amount} onChange={e => setAmount(e.target.value)} placeholder="Amount" />
      <button className="btn" onClick={onTrade}>Gasless Swap</button>
      <div>{status}</div>
    </div>
  );
}