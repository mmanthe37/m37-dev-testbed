import React, { useEffect, useRef } from "react";

export default function ProChart({ symbol }: { symbol: string }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Dynamically load TradingView widget JS and mount chart
    // window.TradingView.widget({...})
  }, [symbol]);

  return (
    <div ref={ref} className="w-full h-[480px] bg-background rounded-xl shadow-omnisphere" />
  );
}