const TOKEN_KEY = "omnisphere_token";

// Secure localStorage usage, in-memory fallback for SSR
export function setToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function removeToken() {
  localStorage.removeItem(TOKEN_KEY);
}

export function getUserFromToken(): any | null {
  try {
    const token = getToken();
    if (!token) return null;
    // You should verify JWT signature on server; here just decode for demo
    const [, payload] = token.split(".");
    return JSON.parse(atob(payload));
  } catch {
    return null;
  }
}