import React from "react";

interface RoutePreviewProps {
  route: any;
}

export const RoutePreview: React.FC<RoutePreviewProps> = ({ route }) => {
  if (!route) return null;
  return (
    <div className="mt-6 bg-black/70 p-4 rounded text-white">
      <h2 className="font-bold text-lg mb-2 text-accentBlue">Best Route Preview</h2>
      <pre>{JSON.stringify(route, null, 2)}</pre>
    </div>
  );
};