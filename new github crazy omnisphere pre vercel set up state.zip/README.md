# OmniSphere EIP-4337 DEX Aggregator Monorepo

A full-stack, modular DEX aggregator with EIP-4337 smart wallet, paymaster, backend aggregator, and modern frontend.  
**Features:**
- Account Abstraction (EIP-4337) Smart Wallet and Paymaster (Solidity)
- Backend (Node.js/Express) with DEX aggregation, paymaster relay, and UserOp sponsorship
- Frontend (React, Vite, Tailwind) with DEX swap UI, EIP-4337 UserOp signing, and visual status
- Docker and Docker Compose for one-command local or cloud deployment
- CI via GitHub Actions

---

## Quickstart

### 1. Clone & Install

```bash
git clone https://github.com/YOUR_ORG/omnisphere-e2e-aa-demo.git
cd omnisphere-e2e-aa-demo
yarn install
```

### 2. Build Contracts

```bash
cd contracts
yarn build
```

### 3. Run Locally (All Services)

```bash
docker-compose up --build
```

- Contracts: runs Hardhat node and compiles
- Backend: runs Express server on port 4000
- Frontend: runs Vite dev server on port 5173

Visit http://localhost:5173 for the UI.

---

## Project Structure

```
contracts/   # Solidity contracts, Hardhat project
backend/     # Node.js/Express API, aggregator, paymaster, relay
frontend/    # Modern React (Vite, Tailwind), DEX UI
```

---

## Environment

- Node.js v18+
- Docker & Docker Compose
- Yarn (recommended) or npm/pnpm

---

## Schema

- Smart Wallet: See `contracts/OmniSmartWallet.sol`
- Paymaster: See `contracts/OmniPaymaster.sol`
- UserOperation: See `frontend/src/userOp.ts` and backend relay

---

## License

MIT