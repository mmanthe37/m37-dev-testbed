import React, { useState } from "react";
import { ethers } from "ethers";
import axios from "axios";
import { buildUserOp, signUserOp } from "./userOp";
import "./index.css";

export default function App() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [amount, setAmount] = useState("");
  const [route, setRoute] = useState<any>(null);
  const [opHash, setOpHash] = useState("");
  const [status, setStatus] = useState("");

  // Demo: EOA private key (for local testing)
  const PRIVATE_KEY = "0x...";
  const ENTRY_POINT = "0xEntryPointAddress";
  const CHAIN_ID = 8453;

  async function handleSwap() {
    setStatus("Fetching best route...");
    const { data } = await axios.post("http://localhost:4000/api/aggregate-swap", { from, to, amount });
    setRoute(data.best);

    setStatus("Building UserOperation...");
    // For demo, fake values for nonce, gas, etc.
    const userOp = buildUserOp({
      sender: "0xSmartWalletAddress",
      dest: data.best.to, // DEX router address
      value: "0",
      data: data.best.data, // DEX swap calldata
      nonce: "0",
      gasLimits: {
        callGasLimit: "200000",
        verificationGasLimit: "150000",
        preVerificationGas: "50000"
      },
      fee: {
        maxFeePerGas: ethers.utils.parseUnits("50", "gwei").toString(),
        maxPriorityFeePerGas: ethers.utils.parseUnits("1", "gwei").toString()
      }
    });

    setStatus("Signing...");
    const signer = new ethers.Wallet(PRIVATE_KEY);
    userOp.signature = await signUserOp(userOp, ENTRY_POINT, CHAIN_ID, signer);

    setStatus("Sending UserOperation for sponsorship/relay...");
    const { data: { opHash } } = await axios.post("http://localhost:4000/api/gasless-trade", { userOp });

    setOpHash(opHash);
    setStatus("Waiting for execution...");
    // Optionally poll /api/userop-receipt/:opHash for completion
  }

  return (
    <div className="container mx-auto mt-10 p-6 rounded bg-gradient-to-br from-indigo-900 to-fuchsia-900 shadow-lg">
      <h1 className="text-3xl font-orbitron mb-6 text-accentBlue font-bold">OmniTrade Gasless DEX Aggregator</h1>
      <div className="flex flex-col gap-3 w-80">
        <input className="rounded p-2 border border-accentBlue" placeholder="From Token Address" value={from} onChange={e => setFrom(e.target.value)} />
        <input className="rounded p-2 border border-accentBlue" placeholder="To Token Address" value={to} onChange={e => setTo(e.target.value)} />
        <input className="rounded p-2 border border-accentBlue" placeholder="Amount (wei)" value={amount} onChange={e => setAmount(e.target.value)} />
        <button className="mt-4 px-4 py-2 rounded bg-gradient-to-r from-accentBlue to-accentPurple text-white font-bold" onClick={handleSwap}>Gasless Swap</button>
      </div>
      <div className="mt-8 text-lg">Status: {status}</div>
      {route && <pre className="mt-6 bg-black/70 p-4 rounded text-white">{JSON.stringify(route, null, 2)}</pre>}
      {opHash && <div className="mt-6 text-accentAqua text-xl">UserOp Hash: {opHash}</div>}
    </div>
  );
}