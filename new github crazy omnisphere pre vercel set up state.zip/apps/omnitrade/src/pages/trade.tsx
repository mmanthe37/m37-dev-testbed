import React from "react";
import { useParams } from "react-router-dom";
import ProChart from "../components/ProChart";
import OrderBook from "../components/OrderBook";
import TradePanel from "../components/TradePanel";
import GaslessStatus from "../components/GaslessStatus";
import { useWallet } from "../hooks/useWallet";

export default function Trade() {
  const { symbol } = useParams<{ symbol?: string }>();
  const { address } = useWallet();
  const pair = symbol || "BTC-USD";
  return (
    <div>
      <h1 className="text-2xl font-orbitron font-bold text-accentBlue mb-4">{`Trade ${pair}`}</h1>
      {address && <GaslessStatus address={address} />}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <ProChart symbol={pair} />
        </div>
        <div>
          <OrderBook />
        </div>
      </div>
      <div className="mt-8">
        <TradePanel symbol={pair} />
      </div>
    </div>
  );
}