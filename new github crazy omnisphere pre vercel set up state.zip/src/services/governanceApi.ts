const API_URL = process.env.REACT_APP_API_BASE_URL;

// List governance proposals
export async function listProposals() {
  const token = localStorage.getItem("omnisphere_token");
  const res = await fetch(`${API_URL}/governance/proposals`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!res.ok) throw new Error("Failed to list proposals");
  return res.json();
}

// Vote on a proposal
export async function voteProposal(id: string, support: boolean) {
  const token = localStorage.getItem("omnisphere_token");
  const res = await fetch(`${API_URL}/governance/vote`, {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({ proposalId: id, support })
  });
  if (!res.ok) throw new Error("Failed to vote");
  return res.json();
}