import { PimlicoPaymasterAPI } from "pimlico-paymaster-sdk";

export async function sponsorUserOp(userOp: any) {
  const paymaster = new PimlicoPaymasterAPI({ apiKey: process.env.PIMLICO_KEY! });
  return await paymaster.sponsorUserOperation(userOp);
}