/**
 * Main navigation component for OmniSphere platform
 */
import { NavLink } from 'react-router'
import { Wallet, TrendingUp, Bot, Waves, Home } from 'lucide-react'

function Navigation() {
  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/omnifi', icon: Wallet, label: 'OmniFi' },
    { path: '/omnitrade', icon: TrendingUp, label: 'OmniTrade' },
    { path: '/omniagent', icon: Bot, label: 'OmniAgent' },
    { path: '/omnipool', icon: Waves, label: 'OmniPool' },
  ]

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-secondary/95 backdrop-blur-md border-b border-border-gray">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-accent-cyan to-accent-magenta rounded-lg flex items-center justify-center">
              <span className="text-primary font-bold text-sm">O</span>
            </div>
            <span className="text-text-white font-bold text-xl">OmniSphere</span>
          </div>
          
          <div className="flex items-center space-x-1">
            {navItems.map(({ path, icon: Icon, label }) => (
              <NavLink
                key={path}
                to={path}
                className={({ isActive }) =>
                  `flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all duration-75 ${
                    isActive
                      ? 'bg-accent-cyan/10 text-accent-cyan border border-accent-cyan/20'
                      : 'text-off-white hover:bg-border-gray hover:text-text-white'
                  }`
                }
              >
                <Icon size={18} />
                <span className="hidden md:block">{label}</span>
              </NavLink>
            ))}
          </div>

          <button className="bg-accent-cyan text-primary px-4 py-2 rounded-lg font-medium hover:glow-cyan hover:scale-105 active:scale-95">
            Connect Wallet
          </button>
        </div>
      </div>
    </nav>
  )
}

export default Navigation
