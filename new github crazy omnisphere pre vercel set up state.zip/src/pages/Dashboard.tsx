import React from "react";
import { MainLayout } from "../components/Layout/MainLayout";
import { FaChartPie, FaCommentDots, FaUsers, FaStar, FaChartLine } from "react-icons/fa";

const stats = [
  {
    label: "Active Users",
    value: "1,247",
    icon: <FaUsers color="#33c6ff" />,
    info: "Active Users",
    color: "#33c6ff"
  },
  {
    label: "Posts Today",
    value: "356",
    icon: <FaCommentDots color="#b36fff" />,
    info: "Posts Today",
    color: "#b36fff"
  },
  {
    label: "Trending Topic",
    value: "$BTC",
    icon: <FaChartLine color="#25f8b3" />,
    info: "Trending Topic",
    color: "#25f8b3"
  }
];

const feed = [
  {
    username: "CryptoPro",
    avatar: "🦊",
    time: "2m ago",
    content: "Just staked my $ETH in the new liquidity pool and earning solid APY! 🚀",
    tags: ["#staking", "#ETH"]
  },
  {
    username: "DeFiDiva",
    avatar: "👩‍💻",
    time: "10m ago",
    content: "Proposal #17 for multi-chain governance is live. Remember to vote!",
    tags: ["#governance", "#DAO"]
  },
  {
    username: "BTCWhale",
    avatar: "🐋",
    time: "25m ago",
    content: "$BTC trending again! Who’s holding through the volatility?",
    tags: ["#BTC", "#trading"]
  }
];

const Dashboard: React.FC = () => {
  return (
    <MainLayout>
      <div className="card card-accent" style={{ marginBottom: 32 }}>
        <h1 style={{ fontFamily: "Orbitron, sans-serif", fontWeight: 700, fontSize: "2.2rem", marginBottom: 8, color: "#b36fff" }}>
          The Sphere
        </h1>
        <div style={{ fontSize: "1.2rem", color: "#a7acd9", marginBottom: 18 }}>
          Your unified Web3 ecosystem hub
        </div>
        <button style={{
          background: "linear-gradient(90deg, #33c6ff 0%, #b36fff 100%)",
          color: "#fff",
          border: "none",
          padding: "0.8em 2em",
          borderRadius: 9,
          fontFamily: "Orbitron, sans-serif",
          fontWeight: 700,
          fontSize: "1.1rem",
          marginBottom: 20
        }}>
          <FaChartPie style={{ marginRight: 12 }} /> View Landing Page
        </button>
      </div>

      <div className="card" style={{ marginBottom: 32 }}>
        <h2 style={{ fontFamily: "Orbitron, sans-serif", color: "#33c6ff", marginBottom: 0 }}>Social Feed</h2>
        <div style={{ color: "#a7acd9", marginBottom: 20 }}>Connect with the Web3 community</div>
        <div style={{ display: "flex", gap: 16, marginBottom: 24 }}>
          <button style={{
            background: "#261a38",
            color: "#b36fff",
            border: "none",
            borderRadius: 8,
            padding: "0.6em 1.5em",
            fontWeight: 700
          }}>
            Trending
          </button>
          <button style={{
            background: "#191e2e",
            color: "#33c6ff",
            border: "none",
            borderRadius: 8,
            padding: "0.6em 1.5em",
            fontWeight: 700
          }}>
            Following
          </button>
        </div>
        <div style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 24,
          marginBottom: 32
        }}>
          {stats.map((s, i) => (
            <div key={i} style={{
              background: "#161622",
              boxShadow: "0 2px 12px #0003",
              borderRadius: 12,
              flex: "1 1 200px",
              display: "flex",
              alignItems: "center",
              gap: 18,
              padding: "1.2em 1.4em",
              minWidth: 220
            }}>
              <div style={{ fontSize: "2em" }}>{s.icon}</div>
              <div>
                <div style={{
                  fontSize: "1.25em",
                  fontWeight: 700,
                  color: s.color,
                  fontFamily: "Orbitron, sans-serif"
                }}>{s.value}</div>
                <div style={{ color: "#a7acd9", fontSize: "1em" }}>{s.info}</div>
              </div>
            </div>
          ))}
        </div>
        {/* Social feed posts */}
        <div>
          {feed.map((post, idx) => (
            <div key={idx} style={{
              display: "flex",
              alignItems: "flex-start",
              gap: 14,
              background: "#191e2e",
              borderRadius: 10,
              padding: "1em",
              marginBottom: 16,
              boxShadow: "0 1px 8px #0001"
            }}>
              <div style={{
                background: "#33c6ff",
                color: "#191e2e",
                borderRadius: "50%",
                height: 38,
                width: 38,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontWeight: 700,
                fontSize: "1.4em"
              }}>
                {post.avatar}
              </div>
              <div>
                <div style={{
                  fontWeight: 700,
                  color: "#b36fff"
                }}>{post.username} <span style={{ color: "#a7acd9", fontWeight: 400, fontSize: "0.95em" }}>{post.time}</span></div>
                <div style={{ color: "#f3f4f6", margin: "0.4em 0" }}>{post.content}</div>
                <div>
                  {post.tags.map((tag, i) => (
                    <span key={i}
                      style={{
                        background: "#261a38",
                        color: "#33c6ff",
                        borderRadius: 6,
                        padding: "0.2em 0.7em",
                        marginRight: 8,
                        fontSize: "0.95em"
                      }}>{tag}</span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Modular dashboard cards, e.g. portfolio, staking, etc. */}
      <div className="card" style={{ background: "#191e2e" }}>
        <h3 style={{ fontFamily: "Orbitron, sans-serif", color: "#b36fff" }}>Your OmniSphere Portfolio</h3>
        <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
          <div style={{
            background: "linear-gradient(90deg, #33c6ff 0%, #b36fff 100%)",
            color: "#191e2e",
            borderRadius: 10,
            padding: "1.6em 2em",
            flex: "1 1 220px",
            minWidth: 220,
            fontWeight: 700,
            fontFamily: "Orbitron, sans-serif",
            fontSize: "1.2em"
          }}>
            $0<br />
            <span style={{ fontWeight: 400, fontSize: "0.9em", color: "#161622" }}>Total Portfolio</span>
            <br /><span style={{ color: "#25f8b3", fontWeight: 600 }}>+12.5%</span>
          </div>
          <div style={{
            background: "#261a38",
            color: "#b36fff",
            borderRadius: 10,
            padding: "1.6em 2em",
            flex: "1 1 220px",
            minWidth: 220,
            fontWeight: 700,
            fontFamily: "Orbitron, sans-serif",
            fontSize: "1.2em"
          }}>
            $0<br />
            <span style={{ fontWeight: 400, fontSize: "0.9em", color: "#a7acd9" }}>Staking Rewards</span>
            <br /><span style={{ color: "#b36fff", fontWeight: 600 }}>APY: 18.5%</span>
          </div>
          <div style={{
            background: "#191e2e",
            color: "#25f8b3",
            borderRadius: 10,
            padding: "1.6em 2em",
            flex: "1 1 220px",
            minWidth: 220,
            fontWeight: 700,
            fontFamily: "Orbitron, sans-serif",
            fontSize: "1.2em"
          }}>
            +$0<br />
            <span style={{ fontWeight: 400, fontSize: "0.9em", color: "#a7acd9" }}>24H PNL</span>
            <br /><span style={{ color: "#25f8b3", fontWeight: 600 }}>Active trades: 12</span>
          </div>
          <div style={{
            background: "#191e2e",
            color: "#33c6ff",
            borderRadius: 10,
            padding: "1.6em 2em",
            flex: "1 1 220px",
            minWidth: 220,
            fontWeight: 700,
            fontFamily: "Orbitron, sans-serif",
            fontSize: "1.2em"
          }}>
            $3,247<br />
            <span style={{ fontWeight: 400, fontSize: "0.9em", color: "#a7acd9" }}>Content Earnings</span>
            <br /><span style={{ color: "#33c6ff", fontWeight: 600 }}>Creator rating: 4.8<FaStar style={{ color: "#33c6ff", marginLeft: 4 }} /></span>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default Dashboard;