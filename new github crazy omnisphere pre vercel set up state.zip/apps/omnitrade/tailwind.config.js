module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    fontFamily: {
      orbitron: ['Orbitron', 'sans-serif'],
      sans: ['Inter', 'sans-serif'],
    },
    extend: {
      colors: {
        background: "#191e2e",
        card: "#261a38",
        accentBlue: "#33c6ff",
        accentPurple: "#b36fff",
        accentAqua: "#33f8a7",
        accentGreen: "#25f8b3",
        text: "#f3f4f6",
        textSecondary: "#a7acd9",
      },
      borderRadius: {
        xl: "1rem",
      },
      boxShadow: {
        omnisphere: "0 6px 16px #0003",
      },
    },
  },
  plugins: [],
};