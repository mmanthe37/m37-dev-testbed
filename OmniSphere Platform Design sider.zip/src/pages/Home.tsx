/**
 * Home page - Main landing and dashboard for OmniSphere
 */
import { ArrowRight, Wallet, TrendingUp, Bot, Waves, Shield, Zap, Globe } from 'lucide-react'
import { Link } from 'react-router'
import Card from '../components/ui/Card'
import Button from '../components/ui/Button'

function Home() {
  const hubs = [
    {
      name: 'OmniFi',
      description: 'Manage your NFT collections and digital assets with advanced analytics',
      icon: Wallet,
      path: '/omnifi',
      color: 'cyan',
      stats: '12.5K NFTs Tracked'
    },
    {
      name: 'OmniTrade',
      description: 'Professional trading interface with real-time market data',
      icon: TrendingUp,
      path: '/omnitrade',
      color: 'magenta',
      stats: '$2.3M Volume Today'
    },
    {
      name: 'OmniAgent',
      description: 'AI-powered automated trading strategies and portfolio management',
      icon: Bot,
      path: '/omniagent',
      color: 'cyan',
      stats: '95.2% Success Rate'
    },
    {
      name: 'OmniPool',
      description: 'Liquidity provision and yield farming across multiple protocols',
      icon: Waves,
      path: '/omnipool',
      color: 'magenta',
      stats: '18.5% Average APY'
    }
  ]

  const features = [
    {
      icon: Shield,
      title: 'Enterprise Security',
      description: 'Military-grade encryption and secure wallet infrastructure'
    },
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Sub-second execution with advanced order routing'
    },
    {
      icon: Globe,
      title: 'Multi-Chain',
      description: 'Seamless access across Ethereum, Solana, and Base networks'
    }
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-24 px-4">
        <div className="absolute inset-0 bg-gradient-to-br from-accent-cyan/5 via-transparent to-accent-magenta/5" />
        <div className="relative container mx-auto text-center">
          <h1 className="text-6xl md:text-8xl font-bold text-text-white mb-6 leading-tight">
            Omni<span className="text-accent-cyan">Sphere</span>
          </h1>
          <p className="text-xl md:text-2xl text-off-white mb-8 max-w-3xl mx-auto">
            The ultimate platform for digital asset management, trading, and automation. 
            <span className="text-accent-magenta"> Powered by AI.</span>
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-lg px-8 py-4">
              Get Started <ArrowRight className="ml-2" size={20} />
            </Button>
            <Button variant="ghost" size="lg" className="text-lg px-8 py-4">
              View Documentation
            </Button>
          </div>
        </div>
      </section>

      {/* Platform Features */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-4xl font-bold text-center text-text-white mb-12">
            Platform Features
          </h2>
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {features.map((feature, index) => (
              <Card key={index} hover className="text-center">
                <feature.icon size={48} className="text-accent-cyan mx-auto mb-4" />
                <h3 className="text-xl font-bold text-text-white mb-2">{feature.title}</h3>
                <p className="text-off-white">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Hubs Overview */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-4xl font-bold text-center text-text-white mb-12">
            Explore OmniSphere Hubs
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {hubs.map((hub, index) => (
              <Link key={index} to={hub.path}>
                <Card hover glow={hub.color as 'cyan' | 'magenta'} className="group">
                  <div className="flex items-start space-x-4">
                    <div className={`p-3 rounded-lg ${
                      hub.color === 'cyan' ? 'bg-accent-cyan/10 text-accent-cyan' : 'bg-accent-magenta/10 text-accent-magenta'
                    }`}>
                      <hub.icon size={32} />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-text-white mb-2 group-hover:text-accent-cyan">
                        {hub.name}
                      </h3>
                      <p className="text-off-white mb-3">{hub.description}</p>
                      <div className={`text-sm font-medium ${
                        hub.color === 'cyan' ? 'text-accent-cyan' : 'text-accent-magenta'
                      }`}>
                        {hub.stats}
                      </div>
                    </div>
                    <ArrowRight 
                      size={24} 
                      className="text-border-gray group-hover:text-accent-cyan transform group-hover:translate-x-2" 
                    />
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Real-time Stats */}
      <section className="py-16 px-4 bg-secondary/50">
        <div className="container mx-auto">
          <h2 className="text-4xl font-bold text-center text-text-white mb-12">
            Platform Statistics
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-accent-cyan mb-2">$127M+</div>
              <div className="text-off-white">Total Volume</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-accent-magenta mb-2">45,213</div>
              <div className="text-off-white">Active Users</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-success-green mb-2">99.97%</div>
              <div className="text-off-white">Uptime</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-accent-cyan mb-2">24/7</div>
              <div className="text-off-white">Support</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home
