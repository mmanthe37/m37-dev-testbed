import axios from "axios";

export function useApi() {
  const token = localStorage.getItem("omnisphere_token");
  const api = axios.create({
    baseURL: process.env.REACT_APP_API_BASE_URL || "http://localhost:4000/api/v1",
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
  return api;
}