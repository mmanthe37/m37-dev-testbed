import { ethers, Wallet } from "ethers";
import { AbiCoder, keccak256, arrayify } from "ethers/lib/utils";

export function encodeExecute(dest: string, value: string, data: string) {
  const iface = new ethers.utils.Interface([
    "function execute(address dest, uint256 value, bytes data)"
  ]);
  return iface.encodeFunctionData("execute", [dest, value, data]);
}

export function buildUserOp({
  sender,
  dest,
  value,
  data,
  nonce,
  gasLimits,
  fee,
  paymasterAndData = "0x",
  initCode = "0x"
}: {
  sender: string;
  dest: string;
  value: string;
  data: string;
  nonce: string;
  gasLimits: { callGasLimit: string; verificationGasLimit: string; preVerificationGas: string; };
  fee: { maxFeePerGas: string; maxPriorityFeePerGas: string; };
  paymasterAndData?: string;
  initCode?: string;
}) {
  return {
    sender,
    nonce,
    initCode,
    callData: encodeExecute(dest, value, data),
    callGasLimit: gasLimits.callGasLimit,
    verificationGasLimit: gasLimits.verificationGasLimit,
    preVerificationGas: gasLimits.preVerificationGas,
    maxFeePerGas: fee.maxFeePerGas,
    maxPriorityFeePerGas: fee.maxPriorityFeePerGas,
    paymasterAndData,
    signature: "0x"
  };
}

export function getUserOpHash(userOp: any, entryPoint: string, chainId: number) {
  const abiCoder = new AbiCoder();
  const packed = abiCoder.encode(
    [
      "address", "uint256", "bytes", "bytes", "uint256", "uint256", "uint256",
      "uint256", "uint256", "bytes", "bytes"
    ],
    [
      userOp.sender,
      userOp.nonce,
      userOp.initCode,
      userOp.callData,
      userOp.callGasLimit,
      userOp.verificationGasLimit,
      userOp.preVerificationGas,
      userOp.maxFeePerGas,
      userOp.maxPriorityFeePerGas,
      userOp.paymasterAndData,
      userOp.signature
    ]
  );
  return keccak256(
    abiCoder.encode(
      ["bytes32", "address", "uint256"],
      [keccak256(packed), entryPoint, chainId]
    )
  );
}

export async function signUserOp(userOp: any, entryPoint: string, chainId: number, signer: Wallet) {
  const hash = getUserOpHash(userOp, entryPoint, chainId);
  return await signer.signMessage(arrayify(hash));
}