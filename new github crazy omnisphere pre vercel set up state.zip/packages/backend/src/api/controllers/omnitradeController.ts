import { Request, Response } from "express";
import { findBestDexRoute } from "../../services/dexAggregator";
import { sponsorUserOp } from "../../services/paymaster";

// 1. Return best DEX route
export async function aggregateSwap(req: Request, res: Response) {
  const { from, to, amount } = req.body;
  if (!from || !to || !amount) return res.status(400).json({ error: "Missing params" });
  try {
    const bestRoute = await findBestDexRoute({ from, to, amount });
    res.json(bestRoute);
  } catch (e) {
    res.status(500).json({ error: "Aggregator failed", details: e });
  }
}

// 2. Sponsor and submit EIP-4337 UserOperation for swap
export async function gaslessTrade(req: Request, res: Response) {
  const { userOp } = req.body;
  if (!userOp) return res.status(400).json({ error: "Missing UserOperation" });
  try {
    const sponsoredOp = await sponsorUserOp(userOp);
    // You would then send sponsoredOp to a bundler (not shown here)
    res.json({ success: true, sponsoredOp });
  } catch (e) {
    res.status(400).json({ error: "Gasless trade failed", details: e });
  }
}