import React, { useEffect, useState } from "react";
import { listPools, depositLiquidity, withdrawLiquidity } from "../services/liquidityApi";
import { MainLayout } from "../components/Layout/MainLayout";
import { FaCoins } from "react-icons/fa";

const Liquidity: React.FC = () => {
  const [pools, setPools] = useState<any[]>([]);
  const [selectedPool, setSelectedPool] = useState<any>(null);
  const [amount, setAmount] = useState<string>("");
  const [error, setError] = useState<string>("");

  useEffect(() => {
    async function load() {
      try {
        const data = await listPools();
        setPools(data);
      } catch {
        setError("Could not load liquidity pools.");
      }
    }
    load();
  }, []);

  const handleDeposit = async () => {
    if (!selectedPool || !amount) return;
    setError("");
    try {
      await depositLiquidity(selectedPool.id, amount);
      setAmount("");
      setSelectedPool(null);
      setPools(await listPools());
    } catch {
      setError("Deposit failed.");
    }
  };

  const handleWithdraw = async () => {
    if (!selectedPool || !amount) return;
    setError("");
    try {
      await withdrawLiquidity(selectedPool.id, amount);
      setAmount("");
      setSelectedPool(null);
      setPools(await listPools());
    } catch {
      setError("Withdraw failed.");
    }
  };

  return (
    <MainLayout>
      <div className="card card-accent">
        <h2><FaCoins /> Liquidity Pools</h2>
        {error && <div className="error-msg">{error}</div>}
        <ul>
          {pools.map(pool => (
            <li key={pool.id} style={{ marginBottom: "1.5em", background: "#261a38", borderRadius: "8px", padding: "1em" }}>
              <b style={{ color: "#33c6ff" }}>{pool.name}</b> <span style={{ color: "#a7acd9" }}>({pool.assets.join(" / ")})</span><br />
              <span style={{ color: "#b36fff" }}>TVL: </span>{pool.tvl}
              <br />
              <span style={{ color: "#33f8a7" }}>Your Balance: </span>{pool.userBalance}
              <div style={{ marginTop: "0.7em" }}>
                <button onClick={() => setSelectedPool(pool)}>
                  Manage
                </button>
              </div>
            </li>
          ))}
        </ul>
        {selectedPool && (
          <div className="liquidity-actions" style={{ marginTop: "2em", background: "#191e2e", borderRadius: "10px", padding: "2em" }}>
            <h3 style={{ color: "#33c6ff" }}>Manage {selectedPool.name}</h3>
            <input
              type="number"
              min="0"
              placeholder="Amount"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              required
            />
            <button onClick={handleDeposit} style={{ marginRight: "1em" }}>Deposit</button>
            <button onClick={handleWithdraw} style={{ background: "#b36fff", color: "#191e2e" }}>Withdraw</button>
            <button onClick={() => { setSelectedPool(null); setAmount(""); }} style={{ marginLeft: "1em", background: "#2a2e38", color: "#fff" }}>Cancel</button>
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default Liquidity;