import axios from "axios";

const PAYMASTER_API_KEY = process.env.PIMLICO_KEY;
const PAYMASTER_API = "https://api.pimlico.io/v1/base/paymaster/sponsorUserOperation";

export async function sponsorUserOp(userOp: any) {
  // Call external paymaster API (here: Pimlico demo)
  const res = await axios.post(PAYMASTER_API, { userOperation: userOp }, {
    headers: { "Authorization": `Bearer ${PAYMASTER_API_KEY}` }
  });
  return { ...userOp, paymasterAndData: res.data.paymasterAndData };
}