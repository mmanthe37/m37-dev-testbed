// UserOperation construction and signing for EIP-4337
import { Wallet, ethers } from "ethers";
import { AbiCoder, keccak256, arrayify, hexlify } from "ethers/lib/utils";

// Minimal EIP-4337 UserOperation interface
export interface UserOperation {
  sender: string;
  nonce: string;
  initCode: string;
  callData: string;
  callGasLimit: string;
  verificationGasLimit: string;
  preVerificationGas: string;
  maxFeePerGas: string;
  maxPriorityFeePerGas: string;
  paymasterAndData: string;
  signature: string;
}

// Utility: encode calldata for smart wallet "execute"
export function encodeExecute(dest: string, value: string, data: string) {
  // Omnisphere smart wallet ABI for "execute"
  const iface = new ethers.utils.Interface([
    "function execute(address dest, uint256 value, bytes data)"
  ]);
  return iface.encodeFunctionData("execute", [dest, value, data]);
}

// Utility: build UserOperation (leave signature blank at first)
export function buildUserOp({
  sender,
  dest,
  value,
  data,
  nonce,
  gasLimits,
  fee,
  paymasterAndData = "0x",
  initCode = "0x"
}: {
  sender: string;
  dest: string;
  value: string;
  data: string;
  nonce: string;
  gasLimits: { callGasLimit: string; verificationGasLimit: string; preVerificationGas: string; };
  fee: { maxFeePerGas: string; maxPriorityFeePerGas: string; };
  paymasterAndData?: string;
  initCode?: string;
}): UserOperation {
  return {
    sender,
    nonce,
    initCode,
    callData: encodeExecute(dest, value, data),
    callGasLimit: gasLimits.callGasLimit,
    verificationGasLimit: gasLimits.verificationGasLimit,
    preVerificationGas: gasLimits.preVerificationGas,
    maxFeePerGas: fee.maxFeePerGas,
    maxPriorityFeePerGas: fee.maxPriorityFeePerGas,
    paymasterAndData,
    signature: "0x"
  };
}

// Utility: Compute the UserOp hash (EIP-4337 EntryPoint hash, simplified for demo)
export function getUserOpHash(userOp: UserOperation, entryPoint: string, chainId: number): string {
  // In production, use EntryPoint's getUserOpHash (EIP-712, see AA SDK)
  // Here, a simple hash for demonstration:
  const abiCoder = new AbiCoder();
  const packed = abiCoder.encode(
    [
      "address", "uint256", "bytes", "bytes", "uint256", "uint256", "uint256",
      "uint256", "uint256", "bytes", "bytes"
    ],
    [
      userOp.sender,
      userOp.nonce,
      userOp.initCode,
      userOp.callData,
      userOp.callGasLimit,
      userOp.verificationGasLimit,
      userOp.preVerificationGas,
      userOp.maxFeePerGas,
      userOp.maxPriorityFeePerGas,
      userOp.paymasterAndData,
      userOp.signature
    ]
  );
  return keccak256(
    abiCoder.encode(
      ["bytes32", "address", "uint256"],
      [keccak256(packed), entryPoint, chainId]
    )
  );
}

// Utility: Sign UserOp hash
export async function signUserOp(userOp: UserOperation, entryPoint: string, chainId: number, signer: Wallet): Promise<string> {
  const hash = getUserOpHash(userOp, entryPoint, chainId);
  return await signer.signMessage(arrayify(hash));
}