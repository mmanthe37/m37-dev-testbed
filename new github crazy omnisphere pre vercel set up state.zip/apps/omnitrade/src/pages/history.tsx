import React from "react";
import TradeHistory from "../components/TradeHistory";

export default function History() {
  return (
    <div>
      <h1 className="text-2xl font-orbitron font-bold text-accentBlue mb-4">Trade History</h1>
      <TradeHistory />
    </div>
  );
}