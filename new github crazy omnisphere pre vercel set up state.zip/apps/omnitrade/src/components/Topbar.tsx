import React from "react";
import { FaUserCircle } from "react-icons/fa";

export default function Topbar() {
  return (
    <header className="flex justify-between items-center px-4 py-4 bg-transparent border-b border-[#2a2e38]">
      <div>
        <div className="text-2xl font-orbitron font-bold bg-gradient-to-r from-accentBlue to-accentPurple bg-clip-text text-transparent">
          OMNITRADE
        </div>
        <div className="text-sm text-textSecondary">The Trading Command Center</div>
      </div>
      <button className="flex items-center gap-2 bg-gradient-to-r from-accentBlue to-accentPurple text-white px-6 py-2 rounded-lg font-orbitron font-bold">
        <FaUserCircle /> Profile
      </button>
    </header>
  );
}