import * as omnitradeController from "./controllers/omnitradeController";

router.post("/omnitrade/aggregate-swap", omnitradeController.aggregateSwap);
router.post("/omnitrade/gasless-trade", omnitradeController.gaslessTrade);