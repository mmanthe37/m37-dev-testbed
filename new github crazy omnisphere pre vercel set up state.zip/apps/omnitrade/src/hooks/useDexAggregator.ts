import { useState } from "react";
import { useApi } from "./useApi";

export function useDexAggregator() {
  const api = useApi();
  const [route, setRoute] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  async function findRoute({ from, to, amount }: { from: string, to: string, amount: string }) {
    setLoading(true);
    const { data } = await api.post("/omnitrade/aggregate-swap", { from, to, amount });
    setRoute(data.best);
    setLoading(false);
  }
  return { findRoute, route, loading };
}