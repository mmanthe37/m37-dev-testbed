import React, { useEffect, useRef } from "react";

// Placeholder: Use a real chart library (e.g., TradingView, Recharts, ApexCharts) in production
export default function Chart({ symbol, data }: { symbol: string; data: { time: string; price: number }[] }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Integrate with charting library here using `ref.current` and `data`
    // For placeholder, just show a minichart
  }, [data]);

  return (
    <div ref={ref} className="bg-background rounded-xl p-4 shadow-omnisphere min-h-[220px] flex items-center justify-center">
      <div className="text-textSecondary">[Chart for {symbol} coming soon]</div>
    </div>
  );
}