/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'primary': '#111111',
        'secondary': '#1A1A1A',
        'accent-cyan': '#00FFFF',
        'accent-magenta': '#FF00FF',
        'text-white': '#FFFFFF',
        'off-white': '#EAEAEA',
        'success-green': '#00FF7F',
        'error-red': '#FF4136',
        'border-gray': '#2B2B2B',
      },
      fontFamily: {
        'sans': ['Inter', 'sans-serif'],
      },
      fontWeight: {
        'regular': '400',
        'medium': '500',
        'bold': '700',
      },
      borderRadius: {
        'DEFAULT': '8px',
      },
      spacing: {
        '4': '4px',
        '8': '8px',
        '16': '16px',
        '24': '24px',
        '32': '32px',
        '40': '40px',
        '48': '48px',
        '64': '64px',
      },
    },
  },
  plugins: [],
}
