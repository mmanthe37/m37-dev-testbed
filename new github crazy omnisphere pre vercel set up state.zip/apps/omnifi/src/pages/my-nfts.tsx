import React, { useEffect, useState } from "react";
import MyNFTs from "../components/MyNFTs";

export default function MyNFTsPage() {
  return (
    <div>
      <h1 className="text-2xl font-orbitron font-bold text-accentBlue mb-4">My NFTs</h1>
      <MyNFTs />
    </div>
  );
}