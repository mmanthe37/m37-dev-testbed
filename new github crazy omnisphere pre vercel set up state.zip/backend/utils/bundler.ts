import axios from "axios";
const ENTRY_POINT_ADDRESS = "0xEntryPointAddress";
const BUNDLER_RPC_URL = "https://api.pimlico.io/v1/base/rpc";

export async function sendUserOperationToBundler(userOp: any) {
  const res = await axios.post(BUNDLER_RPC_URL, {
    jsonrpc: "2.0",
    id: 1,
    method: "eth_sendUserOperation",
    params: [userOp, ENTRY_POINT_ADDRESS]
  });
  if (res.data.error) throw new Error(res.data.error.message);
  return res.data.result; // UserOperationHash
}

export async function getUserOpReceipt(userOpHash: string) {
  const res = await axios.post(BUNDLER_RPC_URL, {
    jsonrpc: "2.0",
    id: 1,
    method: "eth_getUserOperationReceipt",
    params: [userOpHash]
  });
  return res.data.result;
}