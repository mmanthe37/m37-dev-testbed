import { ethers } from "ethers";
import { OmniSmartWallet__factory } from "../../contracts/typechain";

export async function deploySmartWallet(owner: string, entryPoint: string, provider: ethers.JsonRpcProvider, signer: ethers.Signer) {
  const factory = new OmniSmartWallet__factory(signer);
  const wallet = await factory.deploy(owner, entryPoint);
  await wallet.deployed();
  return wallet.address;
}