import { useApi } from "./useApi";

export function useGaslessTrade() {
  const api = useApi();
  async function submitGaslessTrade(userOp: any) {
    const { data } = await api.post("/omnitrade/gasless-trade", { userOp });
    return data;
  }
  return { submitGaslessTrade };
}