export interface UserOperation {
  sender: string;        // Your smart wallet address
  nonce: string;         // Wallet nonce
  initCode: string;      // For first-time wallets, else ""
  callData: string;      // Encoded calldata for your action (e.g., swap)
  callGasLimit: string;  // Estimate
  verificationGasLimit: string;
  preVerificationGas: string;
  maxFeePerGas: string;
  maxPriorityFeePerGas: string;
  paymasterAndData: string;
  signature: string;     // Your EOA's signature over the hash
}