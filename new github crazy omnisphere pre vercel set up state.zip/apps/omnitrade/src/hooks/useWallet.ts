import { useState, useEffect } from "react";
import { Web3Modal } from '@web3modal/ethers/react';

export function useWallet() {
  const [address, setAddress] = useState<string | null>(null);
  const [provider, setProvider] = useState<any>(null);

  useEffect(() => {
    // Initialize Web3Modal (WalletConnect, Coinbase, MetaMask)
    // Example: const modal = new Web3Modal({ ... });
    // On connect, set provider and address
  }, []);

  async function connect() {/* ... */}
  async function disconnect() {/* ... */}
  // Optionally: expose signMessage, sendTx, etc

  return { address, provider, connect, disconnect };
}