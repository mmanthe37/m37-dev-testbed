import React from "react";
import { Link, useLocation } from "react-router-dom";
import { FaChartLine, FaExchangeAlt, FaHistory } from "react-icons/fa";

const navLinks = [
  { path: "/", label: "Markets", icon: <FaChartLine /> },
  { path: "/trade", label: "Trade", icon: <FaExchangeAlt /> },
  { path: "/history", label: "Trade History", icon: <FaHistory /> },
];

export default function SidebarNav({ user }: { user?: { username: string } }) {
  const location = useLocation();
  return (
    <aside className="w-64 p-6 bg-background flex flex-col border-r border-[#2a2e38]">
      <div className="flex items-center mb-12 gap-3">
        <img src="/omnisphere-logo.png" alt="OmniSphere" className="h-9" />
        <span className="text-2xl font-orbitron font-bold text-accentBlue tracking-wide">OmniTrade</span>
      </div>
      <nav className="flex-1">
        {navLinks.map(link => (
          <Link key={link.path}
            to={link.path}
            className={`flex items-center gap-3 px-4 py-3 mb-2 rounded-xl font-orbitron font-bold text-lg transition
              ${location.pathname === link.path || (link.path !== "/" && location.pathname.startsWith(link.path)) ? "bg-gradient-to-r from-accentBlue to-accentPurple text-background" : "text-accentPurple hover:bg-card"}`}
          >
            {link.icon}
            {link.label}
          </Link>
        ))}
      </nav>
      <div className="mt-auto bg-card rounded-lg p-4 flex items-center gap-3">
        <div className="bg-accentBlue text-background rounded-full h-9 w-9 flex items-center justify-center font-bold text-xl">
          {user?.username?.[0]?.toUpperCase() || "G"}
        </div>
        <div>
          <div className="font-bold">{user?.username || "Guest"}</div>
          <div className="text-xs text-textSecondary">{user ? "Trader" : "Guest"}</div>
        </div>
      </div>
    </aside>
  );
}