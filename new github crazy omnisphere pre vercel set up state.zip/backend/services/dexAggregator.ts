import axios from "axios";
export async function findBestDexRoute({ from, to, amount }: { from: string, to: string, amount: string }) {
  // Fetch from 1inch (as example)
  const oneInch = await axios.get(`https://api.1inch.dev/swap/v5.2/1/quote`, {
    params: { fromTokenAddress: from, toTokenAddress: to, amount }
  }).then(r => ({ source: "1inch", ...r.data })).catch(() => null);

  // Fetch from 0x
  const zeroX = await axios.get(`https://api.0x.org/swap/v1/quote`, {
    params: { sellToken: from, buyToken: to, sellAmount: amount }
  }).then(r => ({ source: "0x", ...r.data })).catch(() => null);

  const quotes = [oneInch, zeroX].filter(Boolean);
  quotes.sort((a, b) => (b?.toTokenAmount || 0) - (a?.toTokenAmount || 0));
  return {
    best: quotes[0],
    routes: quotes
  };
}