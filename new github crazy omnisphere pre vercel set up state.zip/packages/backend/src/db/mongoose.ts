import mongoose from "mongoose";

const MONGO_URI = process.env.MONGO_URI!;

mongoose.connect(MONGO_URI, {
  dbName: process.env.DB_NAME || "omnisphere",
}).then(() => {
  console.log("MongoDB connected.");
}).catch((err) => {
  console.error("MongoDB connection failed:", err);
});

export default mongoose;