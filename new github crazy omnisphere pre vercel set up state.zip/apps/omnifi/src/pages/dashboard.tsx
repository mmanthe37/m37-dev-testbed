import React from "react";
import CreatorDashboard from "../components/CreatorDashboard";

export default function Dashboard() {
  return (
    <div>
      <CreatorDashboard />
    </div>
  );
}