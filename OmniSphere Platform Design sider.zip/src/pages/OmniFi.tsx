/**
 * OmniFi Hub - NFT Management and Digital Content
 */
import { useState } from 'react'
import { Image, Plus, Filter, Search, TrendingUp, Eye, ExternalLink } from 'lucide-react'
import Card from '../components/ui/Card'
import Button from '../components/ui/Button'

function OmniFi() {
  const [activeTab, setActiveTab] = useState('collections')
  const [searchTerm, setSearchTerm] = useState('')

  // Mock NFT data
  const collections = [
    {
      id: 1,
      name: 'CyberPunks Collection',
      floorPrice: '2.5 ETH',
      volume24h: '45.2 ETH',
      owned: 3,
      totalValue: '7.5 ETH',
      image: 'https://pub-cdn.sider.ai/u/U0AWHWOKJN3/web-coder/685f947e0385cdf9803db711/resource/cd33b286-97a9-47ba-a6b7-0e783d6b1342.jpg'
    },
    {
      id: 2,
      name: 'Digital Artifacts',
      floorPrice: '1.2 ETH',
      volume24h: '23.1 ETH',
      owned: 8,
      totalValue: '12.8 ETH',
      image: 'https://pub-cdn.sider.ai/u/U0AWHWOKJN3/web-coder/685f947e0385cdf9803db711/resource/3a58efe5-dd26-4dbb-90bb-2b906a8707dc.jpg'
    },
    {
      id: 3,
      name: 'Meta Landscapes',
      floorPrice: '0.8 ETH',
      volume24h: '18.7 ETH',
      owned: 2,
      totalValue: '3.2 ETH',
      image: 'https://pub-cdn.sider.ai/u/U0AWHWOKJN3/web-coder/685f947e0385cdf9803db711/resource/180174fd-64ca-4d54-9491-403cece5e768.jpg'
    }
  ]

  const nfts = [
    {
      id: 1,
      name: 'CyberPunk #2847',
      collection: 'CyberPunks Collection',
      price: '2.8 ETH',
      rarity: 'Rare',
      image: 'https://pub-cdn.sider.ai/u/U0AWHWOKJN3/web-coder/685f947e0385cdf9803db711/resource/11ff3011-55a8-4e05-ad21-fce91cbd97e4.jpg'
    },
    {
      id: 2,
      name: 'Digital Artifact #001',
      collection: 'Digital Artifacts',
      price: '1.5 ETH',
      rarity: 'Epic',
      image: 'https://pub-cdn.sider.ai/u/U0AWHWOKJN3/web-coder/685f947e0385cdf9803db711/resource/b8486056-2bc8-4b32-9a91-220c6ebad8ba.jpg'
    },
    {
      id: 3,
      name: 'Meta Landscape #492',
      collection: 'Meta Landscapes',
      price: '1.1 ETH',
      rarity: 'Common',
      image: 'https://pub-cdn.sider.ai/u/U0AWHWOKJN3/web-coder/685f947e0385cdf9803db711/resource/33100d57-1d7d-4fb7-920a-118c7e969fc2.jpg'
    },
    {
      id: 4,
      name: 'CyberPunk #1203',
      collection: 'CyberPunks Collection',
      price: '3.2 ETH',
      rarity: 'Legendary',
      image: 'https://pub-cdn.sider.ai/u/U0AWHWOKJN3/web-coder/685f947e0385cdf9803db711/resource/3da3f744-da0a-47f7-9b8f-449c94a7acde.jpg'
    }
  ]

  const tabs = [
    { id: 'collections', label: 'My Collections', icon: Image },
    { id: 'nfts', label: 'Individual NFTs', icon: Eye },
    { id: 'create', label: 'Create NFT', icon: Plus }
  ]

  return (
    <div className="min-h-screen p-4">
      <div className="container mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-text-white mb-2">OmniFi</h1>
          <p className="text-off-white text-lg">Manage your NFT portfolio with advanced analytics</p>
        </div>

        {/* Portfolio Overview */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="text-center">
            <div className="text-2xl font-bold text-accent-cyan mb-1">23.5 ETH</div>
            <div className="text-off-white text-sm">Total Portfolio Value</div>
          </Card>
          <Card className="text-center">
            <div className="text-2xl font-bold text-success-green mb-1">+12.3%</div>
            <div className="text-off-white text-sm">24h Change</div>
          </Card>
          <Card className="text-center">
            <div className="text-2xl font-bold text-accent-magenta mb-1">13</div>
            <div className="text-off-white text-sm">Total NFTs</div>
          </Card>
          <Card className="text-center">
            <div className="text-2xl font-bold text-text-white mb-1">3</div>
            <div className="text-off-white text-sm">Collections</div>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="mb-8">
          <div className="flex space-x-1 bg-secondary rounded-lg p-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-accent-cyan text-primary'
                    : 'text-off-white hover:text-text-white'
                }`}
              >
                <tab.icon size={18} />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Search and Filters */}
        {activeTab !== 'create' && (
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 text-border-gray" size={20} />
              <input
                type="text"
                placeholder="Search collections or NFTs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-secondary border border-border-gray rounded-lg pl-10 pr-4 py-3 text-off-white placeholder-border-gray focus:border-accent-cyan focus:outline-none"
              />
            </div>
            <Button variant="ghost">
              <Filter size={18} className="mr-2" />
              Filters
            </Button>
          </div>
        )}

        {/* Content based on active tab */}
        {activeTab === 'collections' && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {collections.map((collection) => (
              <Card key={collection.id} hover glow="cyan">
                <img
                  src={collection.image}
                  alt={collection.name}
                  className="w-full h-48 object-cover rounded-lg mb-4"
                />
                <h3 className="text-xl font-bold text-text-white mb-2">{collection.name}</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-off-white">Floor Price:</span>
                    <span className="text-accent-cyan font-medium">{collection.floorPrice}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-off-white">24h Volume:</span>
                    <span className="text-success-green font-medium">{collection.volume24h}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-off-white">Owned:</span>
                    <span className="text-text-white font-medium">{collection.owned} NFTs</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-off-white">Total Value:</span>
                    <span className="text-accent-magenta font-medium">{collection.totalValue}</span>
                  </div>
                </div>
                <Button className="w-full mt-4">
                  View Collection <ExternalLink size={16} className="ml-2" />
                </Button>
              </Card>
            ))}
          </div>
        )}

        {activeTab === 'nfts' && (
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {nfts.map((nft) => (
              <Card key={nft.id} hover glow="magenta">
                <img
                  src={nft.image}
                  alt={nft.name}
                  className="w-full h-48 object-cover rounded-lg mb-4"
                />
                <h3 className="text-lg font-bold text-text-white mb-1">{nft.name}</h3>
                <p className="text-off-white text-sm mb-2">{nft.collection}</p>
                <div className="flex justify-between items-center mb-3">
                  <span className="text-accent-cyan font-medium">{nft.price}</span>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    nft.rarity === 'Legendary' ? 'bg-accent-magenta/20 text-accent-magenta' :
                    nft.rarity === 'Epic' ? 'bg-accent-cyan/20 text-accent-cyan' :
                    nft.rarity === 'Rare' ? 'bg-success-green/20 text-success-green' :
                    'bg-border-gray text-off-white'
                  }`}>
                    {nft.rarity}
                  </span>
                </div>
                <Button variant="ghost" size="sm" className="w-full">
                  View Details
                </Button>
              </Card>
            ))}
          </div>
        )}

        {activeTab === 'create' && (
          <div className="max-w-2xl mx-auto">
            <Card>
              <h2 className="text-2xl font-bold text-text-white mb-6">Create New NFT</h2>
              <form className="space-y-6">
                <div>
                  <label className="block text-off-white font-medium mb-2">NFT Name</label>
                  <input
                    type="text"
                    placeholder="Enter NFT name"
                    className="w-full bg-primary border border-border-gray rounded-lg px-4 py-3 text-off-white placeholder-border-gray focus:border-accent-cyan focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-off-white font-medium mb-2">Description</label>
                  <textarea
                    placeholder="Describe your NFT"
                    rows={4}
                    className="w-full bg-primary border border-border-gray rounded-lg px-4 py-3 text-off-white placeholder-border-gray focus:border-accent-cyan focus:outline-none resize-none"
                  />
                </div>
                <div>
                  <label className="block text-off-white font-medium mb-2">Upload Image</label>
                  <div className="border-2 border-dashed border-border-gray rounded-lg p-8 text-center hover:border-accent-cyan cursor-pointer">
                    <Image size={48} className="text-border-gray mx-auto mb-4" />
                    <p className="text-off-white">Drag & drop your image here or click to browse</p>
                    <p className="text-border-gray text-sm mt-2">PNG, JPG, GIF up to 10MB</p>
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-off-white font-medium mb-2">Collection</label>
                    <select className="w-full bg-primary border border-border-gray rounded-lg px-4 py-3 text-off-white focus:border-accent-cyan focus:outline-none">
                      <option>Select Collection</option>
                      <option>Create New Collection</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-off-white font-medium mb-2">Royalties (%)</label>
                    <input
                      type="number"
                      placeholder="5"
                      min="0"
                      max="20"
                      className="w-full bg-primary border border-border-gray rounded-lg px-4 py-3 text-off-white placeholder-border-gray focus:border-accent-cyan focus:outline-none"
                    />
                  </div>
                </div>
                <div className="flex space-x-4">
                  <Button className="flex-1">Create NFT</Button>
                  <Button variant="ghost" className="flex-1">Preview</Button>
                </div>
              </form>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}

export default OmniFi
