import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./store/AuthContext";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Governance from "./pages/Governance";
import Liquidity from "./pages/Liquidity";
import Wallet from "./pages/Wallet";
import ProtectedRoute from "./components/Common/ProtectedRoute";
import NotFound from "./pages/NotFound";
import "./styles/global.css";

const App = () => (
  <AuthProvider>
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route element={<ProtectedRoute />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/wallet" element={<Wallet />} />
          <Route path="/governance" element={<Governance />} />
          <Route path="/liquidity" element={<Liquidity />} />
        </Route>
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  </AuthProvider>
);

export default App;