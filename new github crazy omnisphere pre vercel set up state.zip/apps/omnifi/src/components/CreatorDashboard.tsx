import React from "react";
import { Link } from "react-router-dom";

export default function CreatorDashboard() {
  return (
    <div>
      <h1 className="text-3xl font-orbitron font-bold mb-3 text-accentBlue">Welcome to OmniFi</h1>
      <p className="mb-6 text-textSecondary">Publish your work, mint NFTs, and build your digital legacy.</p>
      <div className="flex gap-8 flex-wrap">
        <Link to="/mint" className="bg-gradient-to-r from-accentBlue to-accentPurple text-white px-8 py-4 rounded-xl font-orbitron font-bold text-lg shadow-omnisphere">
          Mint New NFT
        </Link>
        <Link to="/my-nfts" className="bg-card text-accentPurple px-8 py-4 rounded-xl font-orbitron font-bold text-lg shadow-omnisphere border border-accentPurple hover:bg-accentPurple hover:text-background transition">
          View My NFTs
        </Link>
      </div>
    </div>
  );
}