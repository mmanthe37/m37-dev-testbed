import React from "react";

const NotFound: React.FC = () => (
  <div className="not-found">
    <h2>Page Not Found</h2>
    <p>The page you’re looking for does not exist. <a href="/">Return to dashboard</a></p>
  </div>
);

export default NotFound;