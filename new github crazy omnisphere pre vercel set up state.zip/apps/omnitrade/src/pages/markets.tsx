import React from "react";
import MarketList from "../components/MarketList";

export default function Markets() {
  return (
    <div>
      <h1 className="text-2xl font-orbitron font-bold text-accentBlue mb-4">Markets</h1>
      <MarketList />
    </div>
  );
}