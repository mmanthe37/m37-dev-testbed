const API_URL = process.env.REACT_APP_API_BASE_URL;

// List connected wallets for the user
export async function listWallets() {
  const token = localStorage.getItem("omnisphere_token");
  const res = await fetch(`${API_URL}/wallets`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!res.ok) throw new Error("Failed to list wallets");
  return res.json();
}

// Request wallet connection (assume backend initiates WalletConnect, etc)
export async function connectWallet(network: string) {
  const token = localStorage.getItem("omnisphere_token");
  const res = await fetch(`${API_URL}/wallets/connect`, {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({ network })
  });
  if (!res.ok) throw new Error("Failed to connect wallet");
  return res.json();
}

// Disconnect a wallet
export async function disconnectWallet(address: string) {
  const token = localStorage.getItem("omnisphere_token");
  const res = await fetch(`${API_URL}/wallets/disconnect`, {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({ address })
  });
  if (!res.ok) throw new Error("Failed to disconnect wallet");
  return res.json();
}