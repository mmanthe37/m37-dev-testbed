import React, { useEffect, useState } from "react";

// Replace with actual websocket or API data source in production
const mockMarketData = [
  { symbol: "ETH/USD", price: "3452.87" },
  { symbol: "BTC/USD", price: "66820.45" }
];

const MarketData: React.FC = () => {
  const [data, setData] = useState(mockMarketData);

  useEffect(() => {
    // In production: connect to market data WS and update state.
  }, []);

  return (
    <section className="market-data">
      <h3>Market Data</h3>
      <ul>
        {data.map(item => (
          <li key={item.symbol}>
            <span>{item.symbol}</span>
            <span>${item.price}</span>
          </li>
        ))}
      </ul>
    </section>
  );
};

export default MarketData;