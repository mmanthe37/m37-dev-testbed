import React from "react";

// In production, connect to backend or notification service
const notifications = [
  { id: 1, message: "Welcome to OmniSphere! Explore DeFi with confidence." }
];

const Notifications: React.FC = () => (
  <section className="notifications">
    <ul>
      {notifications.map(n => (
        <li key={n.id}>{n.message}</li>
      ))}
    </ul>
  </section>
);

export default Notifications;