import React from "react";
import { Link, useLocation } from "react-router-dom";
import { FaWallet, FaChartPie, FaUser, FaGavel, FaCoins, FaBell, FaCog } from "react-icons/fa";
import "./../../styles/omnisphere.css";

interface MainLayoutProps {
  children: React.ReactNode;
  user?: { username: string; };
}

const navLinks = [
  { path: "/", label: "Dashboard", icon: <FaChartPie /> },
  { path: "/wallet", label: "Wallet", icon: <FaWallet /> },
  { path: "/governance", label: "Governance", icon: <FaGavel /> },
  { path: "/liquidity", label: "Liquidity", icon: <FaCoins /> },
];

export const MainLayout: React.FC<MainLayoutProps> = ({ children, user }) => {
  const location = useLocation();
  return (
    <div className="main-layout">
      <aside className="sidebar">
        <div className="logo">
          <img src="/omnisphere-logo.png" height={38} alt="OmniSphere" />
          OmniSphere
        </div>
        <nav>
          {navLinks.map(link => (
            <Link
              key={link.path}
              to={link.path}
              className={location.pathname === link.path ? "active" : ""}
            >
              {link.icon}
              {link.label}
            </Link>
          ))}
        </nav>
        <button className="view-landing">View Landing Page</button>
        <div className="user-card">
          <span className="user-circle">{user?.username?.[0]?.toUpperCase() || "G"}</span>
          <div>
            <strong>{user?.username || "Guest User"}</strong>
            <div className="user-role">{user ? "Member" : "Guest"}</div>
          </div>
        </div>
      </aside>
      <main style={{ flex: 1 }}>
        <header className="topbar">
          <div>
            <div className="heading">OMNISPHERE</div>
            <div className="subtitle">The Ultimate Web3 Ecosystem</div>
          </div>
          <div className="actions">
            <button>
              <FaWallet style={{ marginRight: 8 }} /> Connect Wallet
            </button>
            <button className="icon-btn"><FaBell /></button>
            <button className="icon-btn"><FaCog /></button>
          </div>
        </header>
        <section className="page-content">
          {children}
        </section>
      </main>
    </div>
  );
};