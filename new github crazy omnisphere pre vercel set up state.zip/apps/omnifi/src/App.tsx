import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import SidebarNav from "./components/SidebarNav";
import Topbar from "./components/Topbar";
import Dashboard from "./pages/dashboard";
import Mint from "./pages/mint";
import MyNFTs from "./pages/my-nfts";
import { useAuth } from "./hooks/useAuth";

function App() {
  const { user } = useAuth();
  return (
    <BrowserRouter>
      <div className="flex min-h-screen">
        <SidebarNav user={user} />
        <div className="flex-1 flex flex-col">
          <Topbar />
          <main className="flex-1 px-6 py-8 bg-[#161622]">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/mint" element={<Mint />} />
              <Route path="/my-nfts" element={<MyNFTs />} />
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </main>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;