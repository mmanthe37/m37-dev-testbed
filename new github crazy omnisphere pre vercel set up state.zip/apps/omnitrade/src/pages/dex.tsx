import React from "react";
import DEXScreen from "../components/DEXScreen";
import DexAggregatorPanel from "../components/DexAggregatorPanel";
import GaslessInfo from "../components/GaslessInfo";

export default function Dex() {
  return (
    <div>
      <GaslessInfo />
      <DexAggregatorPanel />
      <div className="mt-8">
        <DEXScreen />
      </div>
    </div>
  );
}