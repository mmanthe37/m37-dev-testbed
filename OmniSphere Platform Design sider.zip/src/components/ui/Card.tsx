/**
 * Reusable card component with cyber-minimalist styling
 */
import { ReactNode } from 'react'

interface CardProps {
  children: ReactNode
  className?: string
  hover?: boolean
  glow?: 'cyan' | 'magenta' | 'none'
}

function Card({ children, className = '', hover = false, glow = 'none' }: CardProps) {
  const glowClass = glow === 'cyan' ? 'hover:glow-cyan' : glow === 'magenta' ? 'hover:glow-magenta' : ''
  
  return (
    <div 
      className={`
        relative bg-secondary border border-border-gray rounded-lg p-6 noise-texture
        ${hover ? 'hover:border-accent-cyan/50 cursor-pointer' : ''}
        ${glowClass}
        ${className}
      `}
    >
      {children}
    </div>
  )
}

export default Card
