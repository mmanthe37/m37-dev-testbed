import React, { useState } from "react";
import { useApi } from "../hooks/useApi";

export default function MintNFTModal({ onClose }: { onClose: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [minting, setMinting] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const api = useApi();

  const handleMint = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setMinting(true);
    try {
      // 1. Upload content
      const form = new FormData();
      form.append("file", file!);
      form.append("title", title);
      form.append("description", description);
      await api.post("/omnifi/upload", form, { headers: { "Content-Type": "multipart/form-data" } });

      // 2. Mint NFT
      await api.post("/omnifi/mint", { title, description });
      setSuccess("NFT minted successfully!");
    } catch (err) {
      setError("Minting failed.");
    } finally {
      setMinting(false);
    }
  };

  return (
    <div className="fixed z-50 inset-0 bg-black bg-opacity-70 flex items-center justify-center">
      <div className="bg-background rounded-xl p-8 w-full max-w-lg shadow-omnisphere">
        <h2 className="font-orbitron text-2xl font-bold text-accentPurple mb-4">Mint Your NFT</h2>
        <form className="flex flex-col gap-4" onSubmit={handleMint}>
          <input
            type="file"
            accept="image/*,audio/*,text/*"
            onChange={e => setFile(e.target.files?.[0] || null)}
            required
            className="text-white"
          />
          <input
            type="text"
            placeholder="Title"
            className="p-3 rounded-lg bg-card text-white border border-[#2a2e38]"
            value={title}
            onChange={e => setTitle(e.target.value)}
            required
          />
          <textarea
            placeholder="Description"
            className="p-3 rounded-lg bg-card text-white border border-[#2a2e38]"
            value={description}
            onChange={e => setDescription(e.target.value)}
            required
          />
          <div className="flex gap-4 mt-2">
            <button
              type="submit"
              className="bg-gradient-to-r from-accentBlue to-accentPurple text-white px-6 py-2 rounded-lg font-bold"
              disabled={minting}
            >
              {minting ? "Minting..." : "Mint NFT"}
            </button>
            <button type="button" className="bg-card text-accentPurple px-6 py-2 rounded-lg border border-accentPurple font-bold" onClick={onClose} disabled={minting}>
              Cancel
            </button>
          </div>
          {success && <div className="text-accentAqua font-bold">{success}</div>}
          {error && <div className="text-red-400">{error}</div>}
        </form>
      </div>
    </div>
  );
}