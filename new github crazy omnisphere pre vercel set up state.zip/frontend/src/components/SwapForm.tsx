import React, { useState } from "react";

interface SwapFormProps {
  onSwap: (from: string, to: string, amount: string) => void;
  status: string;
}

export const SwapForm: React.FC<SwapFormProps> = ({ onSwap, status }) => {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [amount, setAmount] = useState("");

  return (
    <form
      className="flex flex-col gap-3 w-80"
      onSubmit={e => {
        e.preventDefault();
        onSwap(from, to, amount);
      }}
    >
      <input
        className="rounded p-2 border border-accentBlue"
        placeholder="From Token Address"
        value={from}
        onChange={e => setFrom(e.target.value)}
        required
      />
      <input
        className="rounded p-2 border border-accentBlue"
        placeholder="To Token Address"
        value={to}
        onChange={e => setTo(e.target.value)}
        required
      />
      <input
        className="rounded p-2 border border-accentBlue"
        placeholder="Amount (wei)"
        value={amount}
        onChange={e => setAmount(e.target.value)}
        required
      />
      <button className="mt-4 px-4 py-2 rounded bg-gradient-to-r from-accentBlue to-accentPurple text-white font-bold" type="submit">
        Gasless Swap
      </button>
      <div className="mt-4 text-accentAqua">{status}</div>
    </form>
  );
};