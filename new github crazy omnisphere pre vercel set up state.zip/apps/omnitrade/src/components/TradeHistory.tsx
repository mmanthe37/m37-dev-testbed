import React from "react";

// Replace with real API data
const trades = [
  { symbol: "BTC-USD", side: "buy", amount: "0.2", price: "67000", time: "2025-06-18 10:32" },
  { symbol: "ETH-USD", side: "sell", amount: "1.5", price: "3500", time: "2025-06-17 14:05" },
];

export default function TradeHistory() {
  return (
    <div className="bg-card rounded-xl shadow-omnisphere p-6">
      <table className="w-full text-left">
        <thead>
          <tr className="text-textSecondary">
            <th className="pb-2">Pair</th>
            <th className="pb-2">Side</th>
            <th className="pb-2">Amount</th>
            <th className="pb-2">Price</th>
            <th className="pb-2">Time</th>
          </tr>
        </thead>
        <tbody>
          {trades.map((t, i) => (
            <tr key={i} className="border-t border-[#2a2e38]">
              <td className="py-3 font-orbitron font-bold text-accentBlue">{t.symbol}</td>
              <td className={`py-3 font-bold ${t.side === "buy" ? "text-accentGreen" : "text-red-400"}`}>{t.side.toUpperCase()}</td>
              <td className="py-3">{t.amount}</td>
              <td className="py-3">${t.price}</td>
              <td className="py-3 text-textSecondary">{t.time}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}