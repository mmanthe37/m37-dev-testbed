import React from "react";

// Placeholder order book data
const bids = [
  { price: 66810, size: 0.12 },
  { price: 66800, size: 0.25 },
];
const asks = [
  { price: 66830, size: 0.09 },
  { price: 66840, size: 0.13 },
];

export default function OrderBook() {
  return (
    <div className="bg-card rounded-xl shadow-omnisphere p-4">
      <h3 className="font-orbitron text-accentBlue mb-2 text-lg">Order Book</h3>
      <div className="flex gap-8">
        <div>
          <div className="text-accentGreen font-bold mb-1">Bids</div>
          <table>
            <tbody>
              {bids.map((b, i) => (
                <tr key={i}>
                  <td className="pr-3 text-accentGreen">{b.price}</td>
                  <td>{b.size}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div>
          <div className="text-red-400 font-bold mb-1">Asks</div>
          <table>
            <tbody>
              {asks.map((a, i) => (
                <tr key={i}>
                  <td className="pr-3 text-red-400">{a.price}</td>
                  <td>{a.size}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}