/**
 * OmniTrade Hub - Professional Trading Interface
 */
import { useState } from 'react'
import { TrendingUp, TrendingDown, BarChart3, RefreshCw, Zap } from 'lucide-react'
import Card from '../components/ui/Card'
import Button from '../components/ui/Button'

function OmniTrade() {
  const [selectedPair, setSelectedPair] = useState('ETH/USDC')
  const [orderType, setOrderType] = useState('market')
  const [tradeType, setTradeType] = useState('buy')

  // Mock market data
  const marketData = [
    { symbol: 'BTC/USDC', price: 43250.00, change: 2.45, volume: '2.3B' },
    { symbol: 'ETH/USDC', price: 2850.75, change: -1.23, volume: '1.8B' },
    { symbol: 'SOL/USDC', price: 98.42, change: 5.67, volume: '456M' },
    { symbol: 'AVAX/USDC', price: 36.78, change: -0.89, volume: '234M' },
    { symbol: 'MATIC/USDC', price: 0.87, change: 3.21, volume: '178M' }
  ]

  const portfolio = [
    { asset: 'USDC', balance: 12450.00, value: 12450.00, allocation: 45.2 },
    { asset: 'ETH', balance: 4.25, value: 12115.69, allocation: 44.0 },
    { asset: 'BTC', balance: 0.075, value: 3243.75, allocation: 11.8 }
  ]

  const recentTrades = [
    { pair: 'ETH/USDC', type: 'Buy', amount: '1.5 ETH', price: '2851.20', time: '2 min ago', status: 'Filled' },
    { pair: 'BTC/USDC', type: 'Sell', amount: '0.025 BTC', price: '43180.00', time: '5 min ago', status: 'Filled' },
    { pair: 'SOL/USDC', type: 'Buy', amount: '25 SOL', price: '98.15', time: '12 min ago', status: 'Filled' }
  ]

  return (
    <div className="min-h-screen p-4">
      <div className="container mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-text-white mb-2">OmniTrade</h1>
          <p className="text-off-white text-lg">Professional trading interface with real-time market data</p>
        </div>

        {/* Portfolio Overview */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="text-center">
            <div className="text-2xl font-bold text-accent-cyan mb-1">$27,809.44</div>
            <div className="text-off-white text-sm">Portfolio Value</div>
            <div className="text-success-green text-sm mt-1">+$1,234.56 (4.64%)</div>
          </Card>
          <Card className="text-center">
            <div className="text-2xl font-bold text-success-green mb-1">+8.42%</div>
            <div className="text-off-white text-sm">24h P&L</div>
          </Card>
          <Card className="text-center">
            <div className="text-2xl font-bold text-accent-magenta mb-1">$45,234</div>
            <div className="text-off-white text-sm">24h Volume</div>
          </Card>
          <Card className="text-center">
            <div className="text-2xl font-bold text-text-white mb-1">23</div>
            <div className="text-off-white text-sm">Total Trades</div>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Market Data */}
          <div className="lg:col-span-1">
            <Card>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-text-white">Markets</h2>
                <Button variant="ghost" size="sm">
                  <RefreshCw size={16} />
                </Button>
              </div>
              <div className="space-y-4">
                {marketData.map((market, index) => (
                  <div
                    key={index}
                    onClick={() => setSelectedPair(market.symbol)}
                    className={`p-4 rounded-lg cursor-pointer transition-all ${
                      selectedPair === market.symbol
                        ? 'bg-accent-cyan/10 border border-accent-cyan/20'
                        : 'bg-primary border border-border-gray hover:border-accent-cyan/50'
                    }`}
                  >
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium text-text-white">{market.symbol}</span>
                      <span className={`text-sm ${market.change >= 0 ? 'text-success-green' : 'text-error-red'}`}>
                        {market.change >= 0 ? '+' : ''}{market.change}%
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-bold text-accent-cyan">
                        ${market.price.toLocaleString()}
                      </span>
                      <div className="flex items-center">
                        {market.change >= 0 ? (
                          <TrendingUp size={16} className="text-success-green" />
                        ) : (
                          <TrendingDown size={16} className="text-error-red" />
                        )}
                      </div>
                    </div>
                    <div className="text-sm text-off-white mt-1">Vol: {market.volume}</div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Trading Interface */}
          <div className="lg:col-span-2">
            <div className="grid gap-8">
              {/* Chart Area */}
              <Card>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-text-white">{selectedPair} Chart</h2>
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="sm">1H</Button>
                    <Button variant="ghost" size="sm">4H</Button>
                    <Button size="sm">1D</Button>
                    <Button variant="ghost" size="sm">1W</Button>
                  </div>
                </div>
                <div className="h-64 bg-primary rounded-lg flex items-center justify-center border border-border-gray">
                  <div className="text-center">
                    <BarChart3 size={48} className="text-border-gray mx-auto mb-4" />
                    <p className="text-off-white">TradingView Chart Integration</p>
                    <p className="text-border-gray text-sm">Real-time price data for {selectedPair}</p>
                  </div>
                </div>
              </Card>

              {/* Order Form */}
              <Card>
                <h2 className="text-xl font-bold text-text-white mb-6">Place Order</h2>
                <div className="grid md:grid-cols-2 gap-8">
                  {/* Buy Form */}
                  <div>
                    <div className="flex mb-4">
                      <button
                        onClick={() => setTradeType('buy')}
                        className={`flex-1 py-2 px-4 rounded-l-lg font-medium ${
                          tradeType === 'buy'
                            ? 'bg-success-green text-primary'
                            : 'bg-border-gray text-off-white'
                        }`}
                      >
                        Buy
                      </button>
                      <button
                        onClick={() => setTradeType('sell')}
                        className={`flex-1 py-2 px-4 rounded-r-lg font-medium ${
                          tradeType === 'sell'
                            ? 'bg-error-red text-text-white'
                            : 'bg-border-gray text-off-white'
                        }`}
                      >
                        Sell
                      </button>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-off-white font-medium mb-2">Order Type</label>
                        <select
                          value={orderType}
                          onChange={(e) => setOrderType(e.target.value)}
                          className="w-full bg-primary border border-border-gray rounded-lg px-4 py-3 text-off-white focus:border-accent-cyan focus:outline-none"
                        >
                          <option value="market">Market</option>
                          <option value="limit">Limit</option>
                          <option value="stop">Stop Loss</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-off-white font-medium mb-2">Amount</label>
                        <input
                          type="number"
                          placeholder="0.00"
                          className="w-full bg-primary border border-border-gray rounded-lg px-4 py-3 text-off-white placeholder-border-gray focus:border-accent-cyan focus:outline-none"
                        />
                        <div className="text-sm text-off-white mt-1">Available: 4.25 ETH</div>
                      </div>

                      {orderType === 'limit' && (
                        <div>
                          <label className="block text-off-white font-medium mb-2">Price</label>
                          <input
                            type="number"
                            placeholder="2850.75"
                            className="w-full bg-primary border border-border-gray rounded-lg px-4 py-3 text-off-white placeholder-border-gray focus:border-accent-cyan focus:outline-none"
                          />
                        </div>
                      )}

                      <div>
                        <label className="block text-off-white font-medium mb-2">Total</label>
                        <input
                          type="number"
                          placeholder="0.00 USDC"
                          className="w-full bg-primary border border-border-gray rounded-lg px-4 py-3 text-off-white placeholder-border-gray focus:border-accent-cyan focus:outline-none"
                        />
                      </div>

                      <Button
                        className={`w-full ${
                          tradeType === 'buy' ? 'bg-success-green hover:shadow-success-green/20' : 'bg-error-red hover:shadow-error-red/20'
                        }`}
                      >
                        <Zap size={16} className="mr-2" />
                        {tradeType === 'buy' ? 'Buy' : 'Sell'} {selectedPair.split('/')[0]}
                      </Button>
                    </div>
                  </div>

                  {/* Order Book */}
                  <div>
                    <h3 className="text-lg font-bold text-text-white mb-4">Order Book</h3>
                    <div className="space-y-2">
                      <div className="grid grid-cols-3 text-sm text-off-white font-medium mb-2">
                        <span>Price</span>
                        <span>Size</span>
                        <span>Total</span>
                      </div>
                      {/* Sell orders */}
                      <div className="space-y-1">
                        {[2851.25, 2851.50, 2851.75, 2852.00].map((price, i) => (
                          <div key={i} className="grid grid-cols-3 text-sm text-error-red">
                            <span>${price}</span>
                            <span>{(Math.random() * 10).toFixed(2)}</span>
                            <span>{(price * Math.random() * 10).toFixed(0)}</span>
                          </div>
                        ))}
                      </div>
                      
                      <div className="text-center py-2 text-lg font-bold text-accent-cyan">
                        $2,850.75
                      </div>
                      
                      {/* Buy orders */}
                      <div className="space-y-1">
                        {[2850.50, 2850.25, 2850.00, 2849.75].map((price, i) => (
                          <div key={i} className="grid grid-cols-3 text-sm text-success-green">
                            <span>${price}</span>
                            <span>{(Math.random() * 10).toFixed(2)}</span>
                            <span>{(price * Math.random() * 10).toFixed(0)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>

        {/* Portfolio & Recent Trades */}
        <div className="grid lg:grid-cols-2 gap-8 mt-8">
          {/* Portfolio */}
          <Card>
            <h2 className="text-xl font-bold text-text-white mb-6">Portfolio</h2>
            <div className="space-y-4">
              {portfolio.map((asset, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-primary rounded-lg border border-border-gray">
                  <div>
                    <div className="font-bold text-text-white">{asset.asset}</div>
                    <div className="text-sm text-off-white">{asset.balance} {asset.asset}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-accent-cyan">${asset.value.toLocaleString()}</div>
                    <div className="text-sm text-off-white">{asset.allocation}%</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Recent Trades */}
          <Card>
            <h2 className="text-xl font-bold text-text-white mb-6">Recent Trades</h2>
            <div className="space-y-4">
              {recentTrades.map((trade, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-primary rounded-lg border border-border-gray">
                  <div>
                    <div className="font-bold text-text-white">{trade.pair}</div>
                    <div className="text-sm text-off-white">{trade.time}</div>
                  </div>
                  <div className="text-center">
                    <div className={`font-medium ${trade.type === 'Buy' ? 'text-success-green' : 'text-error-red'}`}>
                      {trade.type} {trade.amount}
                    </div>
                    <div className="text-sm text-off-white">${trade.price}</div>
                  </div>
                  <div className="text-right">
                    <div className="px-2 py-1 bg-success-green/20 text-success-green rounded text-xs font-medium">
                      {trade.status}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default OmniTrade
