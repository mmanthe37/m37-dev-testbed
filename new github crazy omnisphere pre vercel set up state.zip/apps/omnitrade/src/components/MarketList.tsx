import React from "react";
import { Link } from "react-router-dom";

// Sample market data; replace with API call
const markets = [
  { symbol: "BTC-USD", name: "Bitcoin / USD", price: "66820.45", change: "+1.2%" },
  { symbol: "ETH-USD", name: "Ethereum / USD", price: "3452.87", change: "-0.5%" },
  { symbol: "SOL-USD", name: "Solana / USD", price: "145.32", change: "+3.1%" },
];

export default function MarketList() {
  return (
    <div className="bg-card rounded-xl shadow-omnisphere p-6">
      <table className="w-full text-left">
        <thead>
          <tr className="text-textSecondary">
            <th className="pb-2">Pair</th>
            <th className="pb-2">Last Price</th>
            <th className="pb-2">24h Change</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {markets.map((m, i) => (
            <tr key={i} className="border-t border-[#2a2e38]">
              <td className="py-3 font-orbitron font-bold text-accentBlue">{m.name}</td>
              <td className="py-3">{m.price}</td>
              <td className={`py-3 font-bold ${m.change.startsWith('+') ? "text-accentGreen" : "text-red-400"}`}>{m.change}</td>
              <td>
                <Link to={`/trade/${m.symbol}`} className="px-4 py-2 bg-gradient-to-r from-accentBlue to-accentPurple text-white rounded-lg font-bold">
                  Trade
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}