import React, { useEffect, useState } from "react";
import { useApi } from "../hooks/useApi";

// Example DEX screen: pools, pairs, and liquidity
export default function DEXScreen() {
  const api = useApi();
  const [pools, setPools] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      // Replace with real API endpoint
      const { data } = await api.get("/omnitrade/dex/pools");
      setPools(data || []);
      setLoading(false);
    })();
  }, [api]);

  return (
    <div className="bg-card rounded-xl shadow-omnisphere p-6">
      <h2 className="font-orbitron font-bold text-accentBlue mb-4">DEX Pools & Pairs</h2>
      {loading ? (
        <div className="text-accentPurple">Loading pools...</div>
      ) : (
        <table className="w-full text-left">
          <thead>
            <tr className="text-textSecondary">
              <th className="pb-2">Pair</th>
              <th className="pb-2">DEX</th>
              <th className="pb-2">Liquidity</th>
              <th className="pb-2">APY</th>
            </tr>
          </thead>
          <tbody>
            {pools.map((pool, i) => (
              <tr key={i} className="border-t border-[#2a2e38]">
                <td className="py-3 font-orbitron font-bold text-accentBlue">{pool.pair}</td>
                <td className="py-3">{pool.dex}</td>
                <td className="py-3">{pool.liquidity}</td>
                <td className="py-3">{pool.apy || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}