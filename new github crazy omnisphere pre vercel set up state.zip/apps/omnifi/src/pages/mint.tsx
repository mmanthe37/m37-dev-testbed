import React, { useState } from "react";
import MintNFTModal from "../components/MintNFTModal";

export default function Mint() {
  const [open, setOpen] = useState(true);
  return (
    <div>
      <h1 className="text-2xl font-orbitron font-bold text-accentBlue mb-4">Mint an NFT</h1>
      <p className="mb-6 text-textSecondary">Upload your digital art, music, or text, and mint it as an NFT on-chain.</p>
      {open && <MintNFTModal onClose={() => setOpen(false)} />}
    </div>
  );
}