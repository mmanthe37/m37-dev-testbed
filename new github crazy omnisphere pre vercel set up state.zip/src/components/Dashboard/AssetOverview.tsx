import React from "react";

// Replace with real asset fetching logic
const mockAssets = [
  { symbol: "ETH", name: "Ethereum", balance: "3.25" },
  { symbol: "USDC", name: "USD Coin", balance: "742.10" }
];

const AssetOverview: React.FC = () => (
  <section className="asset-overview">
    <h3>Your Assets</h3>
    <ul>
      {mockAssets.map(asset => (
        <li key={asset.symbol}>
          <span className="asset-symbol">{asset.symbol}</span>
          <span className="asset-name">{asset.name}</span>
          <span className="asset-balance">{asset.balance}</span>
        </li>
      ))}
    </ul>
  </section>
);

export default AssetOverview;