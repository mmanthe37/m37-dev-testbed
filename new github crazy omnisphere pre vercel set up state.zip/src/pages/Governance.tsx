import React, { useEffect, useState } from "react";
import { listProposals, voteProposal } from "../services/governanceApi";
import { MainLayout } from "../components/Layout/MainLayout";
import { FaGavel } from "react-icons/fa";

const Governance: React.FC = () => {
  const [proposals, setProposals] = useState<any[]>([]);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    async function load() {
      try {
        const data = await listProposals();
        setProposals(data);
      } catch {
        setError("Could not load proposals.");
      }
    }
    load();
  }, []);

  const handleVote = async (id: string, support: boolean) => {
    setError("");
    try {
      await voteProposal(id, support);
      const data = await listProposals();
      setProposals(data);
    } catch {
      setError("Vote failed.");
    }
  };

  return (
    <MainLayout>
      <div className="card card-accent">
        <h2><FaGavel /> Governance</h2>
        {error && <div className="error-msg">{error}</div>}
        <ul>
          {proposals.map(p => (
            <li key={p.id} style={{ marginBottom: "1.2em", padding: "1em", borderRadius: "8px", background: "#261a38" }}>
              <div style={{ fontWeight: "bold", fontSize: "1.1em", color: "#b36fff" }}>{p.title}</div>
              <div style={{ color: "#a7acd9", margin: "0.5em 0" }}>{p.description}</div>
              <div>Status: <b style={{ color: p.status === "active" ? "#33f8a7" : "#b36fff" }}>{p.status}</b></div>
              <div style={{ marginTop: "0.7em" }}>
                <button
                  disabled={p.status !== "active"}
                  onClick={() => handleVote(p.id, true)}
                >
                  Vote For
                </button>
                <button
                  disabled={p.status !== "active"}
                  onClick={() => handleVote(p.id, false)}
                  style={{ marginLeft: "0.8em", background: "#b36fff", color: "#191e2e" }}
                >
                  Vote Against
                </button>
                <span style={{ marginLeft: "1.5em", fontWeight: "bold", color: "#33c6ff" }}>
                  For: {p.forVotes} | Against: {p.againstVotes}
                </span>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </MainLayout>
  );
};

export default Governance;