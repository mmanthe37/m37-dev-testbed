import { useState } from "react";

export function useAuth() {
  // NOTE: Replace with actual auth context or logic
  const [user] = useState<{ username: string } | null>(() => {
    // Example: parse JWT from localStorage
    const token = localStorage.getItem("omnisphere_token");
    if (!token) return null;
    try {
      const [, payload] = token.split(".");
      return JSON.parse(atob(payload));
    } catch {
      return null;
    }
  });
  return { user };
}