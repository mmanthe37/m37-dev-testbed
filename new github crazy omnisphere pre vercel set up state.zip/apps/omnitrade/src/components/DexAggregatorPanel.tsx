import React, { useState } from "react";
import { useApi } from "../hooks/useApi";

export default function DexAggregatorPanel() {
  const api = useApi();
  const [from, setFrom] = useState("ETH");
  const [to, setTo] = useState("USDC");
  const [amount, setAmount] = useState("");
  const [bestRoute, setBestRoute] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  // Simulate best route fetching from multiple DEXs
  const fetchBestRoute = async () => {
    setLoading(true);
    // Replace with real API call to aggregator
    setTimeout(() => {
      setBestRoute({
        dex: "Uniswap+Sushi",
        price: "3450.90",
        minReceived: "3449.22 USDC"
      });
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="bg-card rounded-xl shadow-omnisphere p-6 max-w-lg">
      <h2 className="font-orbitron font-bold text-accentBlue mb-4">DEX Aggregator Swap</h2>
      <div className="flex gap-4 mb-4">
        <input
          type="text"
          placeholder="From (e.g. ETH)"
          value={from}
          onChange={e => setFrom(e.target.value.toUpperCase())}
          className="p-2 rounded-lg border bg-background border-[#2a2e38] text-white w-28"
        />
        <input
          type="text"
          placeholder="To (e.g. USDC)"
          value={to}
          onChange={e => setTo(e.target.value.toUpperCase())}
          className="p-2 rounded-lg border bg-background border-[#2a2e38] text-white w-28"
        />
        <input
          type="number"
          min="0"
          placeholder="Amount"
          value={amount}
          onChange={e => setAmount(e.target.value)}
          className="p-2 rounded-lg border bg-background border-[#2a2e38] text-white w-28"
        />
        <button
          className="bg-gradient-to-r from-accentBlue to-accentPurple text-white px-6 py-2 rounded-lg font-bold"
          onClick={fetchBestRoute}
          disabled={loading}
        >
          {loading ? "Searching..." : "Find Best Route"}
        </button>
      </div>
      {bestRoute && (
        <div className="bg-background p-4 rounded-lg mt-4">
          <div><span className="font-bold text-accentAqua">Best DEX Route:</span> {bestRoute.dex}</div>
          <div><span className="font-bold">Execution Price:</span> {bestRoute.price} {to}</div>
          <div><span className="font-bold">Min. Received:</span> {bestRoute.minReceived}</div>
        </div>
      )}
    </div>
  );
}