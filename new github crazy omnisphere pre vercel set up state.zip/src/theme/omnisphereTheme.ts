export const omnisphereTheme = {
  colors: {
    background: 'linear-gradient(135deg, #191e2e 0%, #3c1fa8 100%)',
    card: '#191e2e',
    cardSecondary: '#261a38',
    accentBlue: '#33c6ff',
    accentPurple: '#b36fff',
    accentAqua: '#33f8a7',
    accentGradient: 'linear-gradient(90deg, #33c6ff 0%, #b36fff 100%)',
    success: '#25f8b3',
    error: '#ff6565',
    border: '#2a2e38',
    text: '#f3f4f6',
    textSecondary: '#a7acd9',
    button: 'linear-gradient(90deg, #33c6ff 0%, #b36fff 100%)',
    buttonText: '#fff',
    buttonSecondary: '#191e2e',
  },
  font: {
    family: `'Orbitron', 'Inter', Arial, sans-serif`,
    heading: 'Orbitron, sans-serif',
    weightBold: 700,
    weightNormal: 400,
  },
  borderRadius: '12px',
  boxShadow: '0 8px 24px #0005'
};