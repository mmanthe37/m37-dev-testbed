const API_URL = process.env.REACT_APP_API_BASE_URL;

// List available liquidity pools
export async function listPools() {
  const token = localStorage.getItem("omnisphere_token");
  const res = await fetch(`${API_URL}/liquidity/pools`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!res.ok) throw new Error("Failed to list pools");
  return res.json();
}

// Deposit into liquidity pool
export async function depositLiquidity(poolId: string, amount: string) {
  const token = localStorage.getItem("omnisphere_token");
  const res = await fetch(`${API_URL}/liquidity/deposit`, {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({ poolId, amount })
  });
  if (!res.ok) throw new Error("Deposit failed");
  return res.json();
}

// Withdraw from liquidity pool
export async function withdrawLiquidity(poolId: string, amount: string) {
  const token = localStorage.getItem("omnisphere_token");
  const res = await fetch(`${API_URL}/liquidity/withdraw`, {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({ poolId, amount })
  });
  if (!res.ok) throw new Error("Withdraw failed");
  return res.json();
}