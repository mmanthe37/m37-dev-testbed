import React, { useState } from "react";
import { useWallet } from "../hooks/useWallet";
import { useApi } from "../hooks/useApi";

export default function X402PayPanel() {
  const { address, provider } = useWallet();
  const api = useApi();
  const [loading, setLoading] = useState(false);
  const [receipt, setReceipt] = useState<any>(null);

  async function payAndFetchSignal() {
    setLoading(true);
    // Backend endpoint initiates payment, then returns data when confirmed
    const { data } = await api.post("/omnitrade/x402-signal", { wallet: address });
    setReceipt(data.receipt);
    setLoading(false);
  }

  return (
    <div>
      <button disabled={loading} onClick={payAndFetchSignal}
        className="bg-gradient-to-r from-accentBlue to-accentPurple text-white px-6 py-2 rounded-lg font-bold">
        {loading ? "Processing..." : "Get Premium Signal (x402 Pay)"}
      </button>
      {receipt && <div className="text-accentAqua mt-2">Signal purchased: {JSON.stringify(receipt)}</div>}
    </div>
  );
}