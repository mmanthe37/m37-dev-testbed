import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import mongoose from "./db/mongoose";
import routes from "./api/routes";
import { errorHandler } from "./api/middleware/errorHandler";
import { logger } from "./utils/logger";
import dotenv from "dotenv";
dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

// Security & middleware
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "2mb" }));

// Rate limiting
app.use(rateLimit({
  windowMs: 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
}));

// API routes
app.use("/api/v1", routes);

// Global error handler
app.use(errorHandler);

if (process.env.NODE_ENV !== "test") {
  app.listen(PORT, () => {
    logger.info(`OmniSphere backend running on port ${PORT}`);
  });
}

export default app;