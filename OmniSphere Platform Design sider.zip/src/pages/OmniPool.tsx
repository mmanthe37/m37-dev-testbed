/**
 * OmniPool Hub - Liquidity Provision and Yield Farming
 */
import { useState } from 'react'
import { Waves, Plus, TrendingUp, TrendingDown, ExternalLink, Zap, Shield } from 'lucide-react'
import Card from '../components/ui/Card'
import Button from '../components/ui/Button'

function OmniPool() {
  const [activeTab, setActiveTab] = useState('pools')
  const [selectedPool, setSelectedPool] = useState<any>(null)
  const [stakeAmount, setStakeAmount] = useState('')

  // Mock liquidity pools data
  const pools = [
    {
      id: 1,
      name: 'ETH-USDC',
      protocol: 'Uniswap V3',
      apy: 18.5,
      tvl: '$234.5M',
      volume24h: '$45.2M',
      tokens: ['ETH', 'USDC'],
      userLiquidity: '$2,450.00',
      fees24h: '$12.34',
      risk: 'Medium'
    },
    {
      id: 2,
      name: 'BTC-ETH',
      protocol: 'Balancer V2',
      apy: 22.3,
      tvl: '$189.2M',
      volume24h: '$32.1M',
      tokens: ['BTC', 'ETH'],
      userLiquidity: '$0.00',
      fees24h: '$0.00',
      risk: 'High'
    },
    {
      id: 3,
      name: 'USDC-DAI',
      protocol: 'Curve',
      apy: 8.7,
      tvl: '$567.8M',
      volume24h: '$89.3M',
      tokens: ['USDC', 'DAI'],
      userLiquidity: '$5,000.00',
      fees24h: '$8.92',
      risk: 'Low'
    },
    {
      id: 4,
      name: 'SOL-USDC',
      protocol: 'Orca',
      apy: 25.1,
      tvl: '$78.4M',
      volume24h: '$15.6M',
      tokens: ['SOL', 'USDC'],
      userLiquidity: '$0.00',
      fees24h: '$0.00',
      risk: 'High'
    }
  ]

  const myPositions = pools.filter(pool => parseFloat(pool.userLiquidity.replace('$', '').replace(',', '')) > 0)

  const yieldFarms = [
    {
      id: 1,
      name: 'ETH-USDC LP Staking',
      protocol: 'SushiSwap',
      baseApy: 18.5,
      rewardApy: 12.3,
      totalApy: 30.8,
      staked: '$2,450.00',
      pendingRewards: '$15.67 SUSHI',
      lockPeriod: 'None'
    },
    {
      id: 2,
      name: 'Curve 3Pool Farming',
      protocol: 'Convex',
      baseApy: 8.7,
      rewardApy: 15.2,
      totalApy: 23.9,
      staked: '$5,000.00',
      pendingRewards: '$23.45 CRV',
      lockPeriod: '7 days'
    }
  ]

  const tabs = [
    { id: 'pools', label: 'Browse Pools', icon: Waves },
    { id: 'positions', label: 'My Positions', icon: TrendingUp },
    { id: 'farming', label: 'Yield Farming', icon: Plus }
  ]

  const handleStake = () => {
    if (selectedPool && stakeAmount) {
      // Simulate staking action
      alert(`Staking ${stakeAmount} USDC in ${selectedPool.name} pool`)
      setSelectedPool(null)
      setStakeAmount('')
    }
  }

  return (
    <div className="min-h-screen p-4">
      <div className="container mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-text-white mb-2">OmniPool</h1>
          <p className="text-off-white text-lg">Liquidity provision and yield farming across multiple protocols</p>
        </div>

        {/* Portfolio Overview */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="text-center">
            <div className="text-2xl font-bold text-accent-cyan mb-1">$7,450.00</div>
            <div className="text-off-white text-sm">Total Liquidity</div>
            <div className="text-success-green text-sm mt-1">+$234.56 (3.25%)</div>
          </Card>
          <Card className="text-center">
            <div className="text-2xl font-bold text-success-green mb-1">$21.26</div>
            <div className="text-off-white text-sm">Daily Fees Earned</div>
          </Card>
          <Card className="text-center">
            <div className="text-2xl font-bold text-accent-magenta mb-1">18.7%</div>
            <div className="text-off-white text-sm">Average APY</div>
          </Card>
          <Card className="text-center">
            <div className="text-2xl font-bold text-text-white mb-1">2</div>
            <div className="text-off-white text-sm">Active Positions</div>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="mb-8">
          <div className="flex space-x-1 bg-secondary rounded-lg p-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-accent-cyan text-primary'
                    : 'text-off-white hover:text-text-white'
                }`}
              >
                <tab.icon size={18} />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content based on active tab */}
        {activeTab === 'pools' && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {pools.map((pool) => (
                <Card key={pool.id} hover glow="cyan">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-bold text-text-white">{pool.name}</h3>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      pool.risk === 'Low' ? 'bg-success-green/20 text-success-green' :
                      pool.risk === 'Medium' ? 'bg-accent-cyan/20 text-accent-cyan' :
                      'bg-error-red/20 text-error-red'
                    }`}>
                      {pool.risk} Risk
                    </span>
                  </div>

                  <div className="text-center mb-4">
                    <div className="text-3xl font-bold text-accent-cyan mb-1">{pool.apy}%</div>
                    <div className="text-off-white text-sm">APY</div>
                  </div>

                  <div className="space-y-2 mb-4 text-sm">
                    <div className="flex justify-between">
                      <span className="text-off-white">Protocol:</span>
                      <span className="text-text-white font-medium">{pool.protocol}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-off-white">TVL:</span>
                      <span className="text-accent-cyan font-medium">{pool.tvl}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-off-white">24h Volume:</span>
                      <span className="text-success-green font-medium">{pool.volume24h}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-off-white">Your Liquidity:</span>
                      <span className="text-accent-magenta font-medium">{pool.userLiquidity}</span>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button 
                      size="sm" 
                      className="flex-1"
                      onClick={() => setSelectedPool(pool)}
                    >
                      <Plus size={16} className="mr-2" />
                      Add Liquidity
                    </Button>
                    <Button variant="ghost" size="sm">
                      <ExternalLink size={16} />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'positions' && (
          <div className="space-y-6">
            {myPositions.length > 0 ? (
              <div className="grid gap-6">
                {myPositions.map((position) => (
                  <Card key={position.id} glow="magenta">
                    <div className="grid md:grid-cols-4 gap-6">
                      <div>
                        <h3 className="text-xl font-bold text-text-white mb-2">{position.name}</h3>
                        <p className="text-off-white text-sm">{position.protocol}</p>
                      </div>
                      
                      <div className="text-center">
                        <div className="text-2xl font-bold text-accent-cyan mb-1">{position.apy}%</div>
                        <div className="text-off-white text-sm">Current APY</div>
                      </div>
                      
                      <div className="text-center">
                        <div className="text-2xl font-bold text-success-green mb-1">{position.userLiquidity}</div>
                        <div className="text-off-white text-sm">Your Liquidity</div>
                        <div className="text-accent-cyan text-sm">Fees: {position.fees24h}</div>
                      </div>
                      
                      <div className="flex flex-col space-y-2">
                        <Button size="sm" variant="ghost">
                          <Plus size={16} className="mr-2" />
                          Add More
                        </Button>
                        <Button size="sm" variant="danger">
                          <TrendingDown size={16} className="mr-2" />
                          Remove
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="text-center py-12">
                <Waves size={64} className="text-border-gray mx-auto mb-4" />
                <h3 className="text-xl font-bold text-text-white mb-2">No Active Positions</h3>
                <p className="text-off-white mb-6">Start earning by providing liquidity to pools</p>
                <Button onClick={() => setActiveTab('pools')}>
                  Browse Pools
                </Button>
              </Card>
            )}
          </div>
        )}

        {activeTab === 'farming' && (
          <div className="space-y-6">
            <div className="grid gap-6">
              {yieldFarms.map((farm) => (
                <Card key={farm.id} glow="cyan">
                  <div className="grid md:grid-cols-5 gap-6 items-center">
                    <div>
                      <h3 className="text-lg font-bold text-text-white mb-1">{farm.name}</h3>
                      <p className="text-off-white text-sm">{farm.protocol}</p>
                    </div>
                    
                    <div className="text-center">
                      <div className="text-xl font-bold text-accent-cyan mb-1">{farm.totalApy}%</div>
                      <div className="text-off-white text-xs">
                        Base: {farm.baseApy}% + Rewards: {farm.rewardApy}%
                      </div>
                    </div>
                    
                    <div className="text-center">
                      <div className="text-lg font-bold text-success-green mb-1">{farm.staked}</div>
                      <div className="text-off-white text-sm">Staked</div>
                    </div>
                    
                    <div className="text-center">
                      <div className="text-lg font-bold text-accent-magenta mb-1">{farm.pendingRewards}</div>
                      <div className="text-off-white text-sm">Pending Rewards</div>
                      <div className="text-border-gray text-xs mt-1">Lock: {farm.lockPeriod}</div>
                    </div>
                    
                    <div className="flex flex-col space-y-2">
                      <Button size="sm">
                        <Zap size={16} className="mr-2" />
                        Claim
                      </Button>
                      <Button size="sm" variant="ghost">
                        <Shield size={16} className="mr-2" />
                        Compound
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Stake Modal */}
        {selectedPool && (
          <div className="fixed inset-0 bg-primary/80 backdrop-blur-md flex items-center justify-center z-50">
            <Card className="w-full max-w-md mx-4">
              <h2 className="text-2xl font-bold text-text-white mb-6">
                Add Liquidity to {selectedPool.name}
              </h2>
              
              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-off-white font-medium mb-2">Amount (USDC)</label>
                  <input
                    type="number"
                    value={stakeAmount}
                    onChange={(e) => setStakeAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-primary border border-border-gray rounded-lg px-4 py-3 text-off-white placeholder-border-gray focus:border-accent-cyan focus:outline-none"
                  />
                  <div className="text-sm text-off-white mt-1">Available: 12,450.00 USDC</div>
                </div>
                
                <div className="bg-primary rounded-lg p-4 border border-border-gray">
                  <div className="text-sm text-off-white mb-2">Pool Details:</div>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-off-white">APY:</span>
                      <span className="text-accent-cyan font-medium">{selectedPool.apy}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-off-white">Protocol:</span>
                      <span className="text-text-white">{selectedPool.protocol}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-off-white">Risk Level:</span>
                      <span className={`font-medium ${
                        selectedPool.risk === 'Low' ? 'text-success-green' :
                        selectedPool.risk === 'Medium' ? 'text-accent-cyan' :
                        'text-error-red'
                      }`}>{selectedPool.risk}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-4">
                <Button className="flex-1" onClick={handleStake}>
                  Add Liquidity
                </Button>
                <Button variant="ghost" className="flex-1" onClick={() => setSelectedPool(null)}>
                  Cancel
                </Button>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}

export default OmniPool
