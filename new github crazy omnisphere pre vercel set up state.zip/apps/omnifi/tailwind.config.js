module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "../../apps/shared-ui/src/**/*.{js,jsx,ts,tsx}", // Optional: if sharing UI
  ],
  theme: {
    fontFamily: {
      orbitron: ['Orbitron', 'sans-serif'],
      sans: ['Inter', 'sans-serif'],
    },
    extend: {
      colors: {
        background: "#191e2e",
        card: "#261a38",
        accentBlue: "#33c6ff",
        accentPurple: "#b36fff",
        accentAqua: "#33f8a7",
        accentGradient: "linear-gradient(90deg, #33c6ff 0%, #b36fff 100%)",
        text: "#f3f4f6",
        textSecondary: "#a7acd9",
      },
      borderRadius: {
        xl: "1rem",
      },
      boxShadow: {
        omnisphere: "0 6px 16px #0003",
      },
    },
  },
  plugins: [],
};