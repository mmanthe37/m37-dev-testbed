// ... other imports
import Dex from "./pages/dex";

function App() {
  const { user } = useAuth();
  return (
    <BrowserRouter>
      <div className="flex min-h-screen">
        <SidebarNav user={user} />
        <div className="flex-1 flex flex-col">
          <Topbar />
          <main className="flex-1 px-6 py-8 bg-[#161622]">
            <Routes>
              <Route path="/" element={<Markets />} />
              <Route path="/trade/:symbol?" element={<Trade />} />
              <Route path="/history" element={<History />} />
              <Route path="/dex" element={<Dex />} />
              {/* Add more advanced routes as needed */}
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </main>
        </div>
      </div>
    </BrowserRouter>
  );
}