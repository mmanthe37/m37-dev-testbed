import express from "express";
import cors from "cors";
import { json } from "body-parser";
import { findBestDexRoute } from "./services/dexAggregator";
import { sponsorUserOp } from "./services/paymaster";
import { sendUserOperationToBundler, getUserOpReceipt } from "./utils/bundler";

const app = express();
app.use(cors());
app.use(json());

app.post("/api/aggregate-swap", async (req, res) => {
  const { from, to, amount } = req.body;
  try {
    const bestRoute = await findBestDexRoute({ from, to, amount });
    res.json(bestRoute);
  } catch (e) {
    res.status(500).json({ error: "Aggregator failed", details: String(e) });
  }
});

app.post("/api/gasless-trade", async (req, res) => {
  const { userOp } = req.body;
  try {
    const sponsoredOp = await sponsorUserOp(userOp);
    const opHash = await sendUserOperationToBundler(sponsoredOp);
    res.json({ opHash });
  } catch (e) {
    res.status(400).json({ error: "Gasless trade failed", details: String(e) });
  }
});

app.get("/api/userop-receipt/:opHash", async (req, res) => {
  try {
    const receipt = await getUserOpReceipt(req.params.opHash);
    res.json(receipt);
  } catch (e) {
    res.status(404).json({ error: "Receipt not found", details: String(e) });
  }
});

app.listen(4000, () => console.log("Backend running at http://localhost:4000"));