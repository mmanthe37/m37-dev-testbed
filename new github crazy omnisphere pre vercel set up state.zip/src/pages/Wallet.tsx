import React, { useEffect, useState } from "react";
import { listWallets, connectWallet, disconnectWallet } from "../services/walletApi";
import { MainLayout } from "../components/Layout/MainLayout";
import { FaEthereum, FaWallet, FaPlus } from "react-icons/fa";

const Wallet: React.FC = () => {
  const [wallets, setWallets] = useState<any[]>([]);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    async function load() {
      try {
        const data = await listWallets();
        setWallets(data);
      } catch {
        setError("Could not load wallets.");
      }
    }
    load();
  }, []);

  const handleConnect = async (network: string) => {
    setError("");
    try {
      await connectWallet(network);
      const data = await listWallets();
      setWallets(data);
    } catch {
      setError("Failed to connect wallet.");
    }
  };

  const handleDisconnect = async (address: string) => {
    setError("");
    try {
      await disconnectWallet(address);
      setWallets(wallets.filter(w => w.address !== address));
    } catch {
      setError("Failed to disconnect wallet.");
    }
  };

  return (
    <MainLayout>
      <div className="card card-accent">
        <h2><FaWallet /> Connected Wallets</h2>
        {error && <div className="error-msg">{error}</div>}
        <ul>
          {wallets.map(w => (
            <li key={w.address} style={{ display: "flex", alignItems: "center", gap: "1em", marginBottom: "1em" }}>
              <FaEthereum color="#33c6ff" />
              <span style={{ fontWeight: "bold" }}>{w.label || w.network}</span>
              <span style={{ fontFamily: "monospace" }}>{w.address}</span>
              <button onClick={() => handleDisconnect(w.address)} style={{ marginLeft: "auto" }}>Disconnect</button>
            </li>
          ))}
        </ul>
        <h3>Connect new wallet</h3>
        <button onClick={() => handleConnect("ethereum")}>
          <FaPlus /> Connect Ethereum
        </button>
        <button onClick={() => handleConnect("polygon")}>
          <FaPlus /> Connect Polygon
        </button>
      </div>
    </MainLayout>
  );
};

export default Wallet;