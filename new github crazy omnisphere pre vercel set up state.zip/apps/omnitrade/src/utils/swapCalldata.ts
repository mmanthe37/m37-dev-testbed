import { Interface } from "ethers/lib/utils";

// Uniswap V2 router ABI fragment
const uniswapAbi = [
  "function swapExactTokensForTokens(uint amountIn, uint amountOutMin, address[] path, address to, uint deadline)"
];

// 1. Prepare arguments
const amountIn = ethers.utils.parseUnits("1.0", 18); // 1 ETH, for example
const amountOutMin = ethers.utils.parseUnits("2000", 6); // 2000 USDC min
const path = [ETH_ADDRESS, USDC_ADDRESS];
const to = SMART_WALLET_ADDRESS;
const deadline = Math.floor(Date.now() / 1000) + 60 * 15;

// 2. Encode calldata
const iface = new Interface(uniswapAbi);
const calldata = iface.encodeFunctionData("swapExactTokensForTokens", [
  amountIn, amountOutMin, path, to, deadline
]);

// 3. Use this in your UserOp.callData!