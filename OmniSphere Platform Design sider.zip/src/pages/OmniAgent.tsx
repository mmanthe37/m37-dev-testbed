/**
 * OmniAgent Hub - AI-Driven Automated Trading Strategies
 */
import { useState, useRef, useEffect } from 'react'
import { Bot, Send, Brain, TrendingUp, Shield, Zap, ChevronDown, Play, Pause, Settings } from 'lucide-react'
import Card from '../components/ui/Card'
import Button from '../components/ui/Button'

interface Message {
  id: number
  type: 'user' | 'agent' | 'thinking' | 'tool'
  content: string
  timestamp: Date
  toolCall?: { name: string; result: any }
}

function OmniAgent() {
  const [activeTab, setActiveTab] = useState('chat')
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      type: 'agent',
      content: "Hello! I'm OmniAgent, your AI-powered trading assistant. I can help you create and deploy automated trading strategies. What would you like to achieve with your portfolio today?",
      timestamp: new Date()
    }
  ])
  const [inputValue, setInputValue] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const [showThinking, setShowThinking] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const strategies = [
    {
      id: 1,
      name: 'Conservative DCA',
      description: 'Dollar-cost averaging with risk management for steady accumulation',
      performance: '+12.4%',
      risk: 'Low',
      active: true,
      assets: ['ETH', 'BTC'],
      allocation: '$2,500'
    },
    {
      id: 2,
      name: 'Volatility Scalper',
      description: 'High-frequency trading on market volatility with stop-losses',
      performance: '+24.7%',
      risk: 'High',
      active: false,
      assets: ['SOL', 'AVAX', 'MATIC'],
      allocation: '$1,200'
    },
    {
      id: 3,
      name: 'Yield Optimizer',
      description: 'Automated yield farming across multiple DeFi protocols',
      performance: '+18.9%',
      risk: 'Medium',
      active: true,
      assets: ['USDC', 'DAI', 'USDT'],
      allocation: '$5,000'
    }
  ]

  const activeAgents = [
    {
      id: 1,
      name: 'Conservative DCA',
      status: 'Running',
      pnl: '+$156.78',
      trades: 12,
      nextAction: 'Buy ETH in 2h 15m'
    },
    {
      id: 3,
      name: 'Yield Optimizer',
      status: 'Running',
      pnl: '+$432.15',
      trades: 8,
      nextAction: 'Rebalance portfolio in 4h'
    }
  ]

  const tabs = [
    { id: 'chat', label: 'AI Assistant', icon: Bot },
    { id: 'strategies', label: 'Strategy Marketplace', icon: Brain },
    { id: 'active', label: 'Active Agents', icon: TrendingUp }
  ]

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const simulateAgentResponse = async (userMessage: string) => {
    setIsProcessing(true)
    
    // Add thinking process
    const thinkingMessage: Message = {
      id: Date.now(),
      type: 'thinking',
      content: "Let me analyze your request and check current market conditions...",
      timestamp: new Date()
    }
    
    setMessages(prev => [...prev, thinkingMessage])
    
    // Simulate thinking delay
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    // Add tool call
    const toolMessage: Message = {
      id: Date.now() + 1,
      type: 'tool',
      content: "Calling get_market_data('ETH', 'volatility_index')",
      timestamp: new Date(),
      toolCall: {
        name: 'get_market_data',
        result: { asset: 'ETH', volatility_index: 85, trend: 'bullish', confidence: 0.72 }
      }
    }
    
    setMessages(prev => [...prev, toolMessage])
    
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Agent response based on user input
    let agentResponse = ""
    if (userMessage.toLowerCase().includes('conservative') || userMessage.toLowerCase().includes('safe')) {
      agentResponse = "Based on current market volatility (85% - High), I recommend a conservative Dollar-Cost Averaging strategy for ETH. Given the high volatility, I'll adjust the parameters: smaller position sizes (2% per trade instead of 5%), wider stop-losses (12% instead of 8%), and reduced frequency to avoid whipsaws. This strategy would start with $100 trades every 3 days, with a maximum exposure of $2,000. Would you like me to configure this strategy for you?"
    } else if (userMessage.toLowerCase().includes('aggressive') || userMessage.toLowerCase().includes('volatile')) {
      agentResponse = "I can see you're interested in a more aggressive approach. Current ETH volatility is at 85% which creates opportunities for volatility trading. However, I recommend starting with medium risk parameters: 3x leverage maximum, 10% stop-loss, and 15% take-profit targets. The Volatility Scalper strategy could work well here. Should I set up a demo run first?"
    } else {
      agentResponse = "I understand you're looking for trading strategy guidance. Based on current market conditions (ETH volatility: 85%, trend: bullish), I can help you with several approaches:\n\n1. **Conservative DCA** - Steady accumulation with risk management\n2. **Volatility Trading** - Capitalize on price swings\n3. **Yield Optimization** - Earn on stable assets\n\nWhat's your risk tolerance and investment timeline?"
    }
    
    const agentMessage: Message = {
      id: Date.now() + 2,
      type: 'agent',
      content: agentResponse,
      timestamp: new Date()
    }
    
    setMessages(prev => [...prev, agentMessage])
    setIsProcessing(false)
  }

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isProcessing) return
    
    const userMessage: Message = {
      id: Date.now(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    }
    
    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    
    await simulateAgentResponse(inputValue)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="min-h-screen p-4">
      <div className="container mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-text-white mb-2">OmniAgent</h1>
          <p className="text-off-white text-lg">AI-powered automated trading strategies and portfolio management</p>
        </div>

        {/* Overview Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="text-center">
            <div className="text-2xl font-bold text-accent-cyan mb-1">95.2%</div>
            <div className="text-off-white text-sm">Success Rate</div>
          </Card>
          <Card className="text-center">
            <div className="text-2xl font-bold text-success-green mb-1">+$2,847.93</div>
            <div className="text-off-white text-sm">Total Profit</div>
          </Card>
          <Card className="text-center">
            <div className="text-2xl font-bold text-accent-magenta mb-1">2</div>
            <div className="text-off-white text-sm">Active Agents</div>
          </Card>
          <Card className="text-center">
            <div className="text-2xl font-bold text-text-white mb-1">127</div>
            <div className="text-off-white text-sm">Total Trades</div>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="mb-8">
          <div className="flex space-x-1 bg-secondary rounded-lg p-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-accent-magenta text-primary'
                    : 'text-off-white hover:text-text-white'
                }`}
              >
                <tab.icon size={18} />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content based on active tab */}
        {activeTab === 'chat' && (
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Card className="h-[600px] flex flex-col">
                <div className="flex items-center justify-between mb-4 pb-4 border-b border-border-gray">
                  <h2 className="text-xl font-bold text-text-white">AI Assistant</h2>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowThinking(!showThinking)}
                  >
                    <Brain size={16} className="mr-2" />
                    {showThinking ? 'Hide' : 'Show'} Thinking
                    <ChevronDown size={16} className={`ml-2 transition-transform ${showThinking ? 'rotate-180' : ''}`} />
                  </Button>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto space-y-4 mb-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`${
                        message.type === 'user' ? 'ml-8' : 
                        message.type === 'thinking' || message.type === 'tool' ? 
                        (showThinking ? 'mr-8' : 'hidden') : 'mr-8'
                      }`}
                    >
                      <div className={`p-4 rounded-lg ${
                        message.type === 'user' 
                          ? 'bg-accent-cyan text-primary ml-auto max-w-md' 
                          : message.type === 'thinking'
                          ? 'bg-accent-magenta/10 border border-accent-magenta/20 text-accent-magenta'
                          : message.type === 'tool'
                          ? 'bg-border-gray/50 text-off-white font-mono text-sm'
                          : 'bg-secondary border border-border-gray text-off-white'
                      }`}>
                        {message.type === 'agent' && (
                          <div className="flex items-center space-x-2 mb-2">
                            <Bot size={16} className="text-accent-magenta" />
                            <span className="text-sm font-medium text-accent-magenta">OmniAgent</span>
                          </div>
                        )}
                        {message.type === 'thinking' && (
                          <div className="flex items-center space-x-2 mb-2">
                            <Brain size={16} className="animate-pulse" />
                            <span className="text-sm font-medium">Thinking...</span>
                          </div>
                        )}
                        {message.type === 'tool' && (
                          <div className="flex items-center space-x-2 mb-2">
                            <Zap size={16} className="text-accent-cyan" />
                            <span className="text-sm font-medium text-accent-cyan">Tool Call</span>
                          </div>
                        )}
                        <div className="whitespace-pre-wrap">{message.content}</div>
                        {message.toolCall && (
                          <div className="mt-2 p-2 bg-primary rounded text-xs">
                            <div className="text-accent-cyan font-medium">Result:</div>
                            <pre className="text-off-white">{JSON.stringify(message.toolCall.result, null, 2)}</pre>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  {isProcessing && (
                    <div className="mr-8">
                      <div className="bg-secondary border border-border-gray p-4 rounded-lg">
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-accent-magenta rounded-full animate-bounce" />
                          <div className="w-2 h-2 bg-accent-magenta rounded-full animate-bounce" style={{animationDelay: '0.1s'}} />
                          <div className="w-2 h-2 bg-accent-magenta rounded-full animate-bounce" style={{animationDelay: '0.2s'}} />
                          <span className="text-off-white ml-2">OmniAgent is thinking...</span>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Message Input */}
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Describe your trading goals or ask about strategies..."
                    className="flex-1 bg-primary border border-border-gray rounded-lg px-4 py-3 text-off-white placeholder-border-gray focus:border-accent-cyan focus:outline-none"
                    disabled={isProcessing}
                  />
                  <Button 
                    onClick={handleSendMessage} 
                    disabled={!inputValue.trim() || isProcessing}
                  >
                    <Send size={16} />
                  </Button>
                </div>
              </Card>
            </div>

            {/* Quick Actions */}
            <div>
              <Card>
                <h3 className="text-lg font-bold text-text-white mb-4">Quick Start</h3>
                <div className="space-y-3">
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-left"
                    onClick={() => setInputValue("I want a conservative strategy for ETH")}
                  >
                    <Shield size={16} className="mr-2" />
                    Conservative ETH Strategy
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-left"
                    onClick={() => setInputValue("Help me with high-volatility trading")}
                  >
                    <Zap size={16} className="mr-2" />
                    Volatility Trading
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-left"
                    onClick={() => setInputValue("Set up yield farming automation")}
                  >
                    <TrendingUp size={16} className="mr-2" />
                    Yield Optimization
                  </Button>
                </div>
              </Card>

              <Card className="mt-6">
                <h3 className="text-lg font-bold text-text-white mb-4">Market Conditions</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-off-white">ETH Volatility:</span>
                    <span className="text-error-red font-medium">High (85%)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-off-white">BTC Trend:</span>
                    <span className="text-success-green font-medium">Bullish</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-off-white">Market Fear:</span>
                    <span className="text-accent-cyan font-medium">Neutral (52)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-off-white">DeFi TVL:</span>
                    <span className="text-success-green font-medium">+2.4%</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        )}

        {activeTab === 'strategies' && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {strategies.map((strategy) => (
              <Card key={strategy.id} hover glow="cyan">
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-xl font-bold text-text-white">{strategy.name}</h3>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    strategy.risk === 'Low' ? 'bg-success-green/20 text-success-green' :
                    strategy.risk === 'Medium' ? 'bg-accent-cyan/20 text-accent-cyan' :
                    'bg-error-red/20 text-error-red'
                  }`}>
                    {strategy.risk} Risk
                  </span>
                </div>
                
                <p className="text-off-white mb-4">{strategy.description}</p>
                
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <span className="text-off-white">Performance:</span>
                    <span className="text-success-green font-medium">{strategy.performance}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-off-white">Assets:</span>
                    <span className="text-text-white font-medium">{strategy.assets.join(', ')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-off-white">Allocation:</span>
                    <span className="text-accent-cyan font-medium">{strategy.allocation}</span>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <Button 
                    size="sm" 
                    className="flex-1"
                    variant={strategy.active ? "secondary" : "primary"}
                  >
                    {strategy.active ? 'Configure' : 'Deploy'}
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Settings size={16} />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}

        {activeTab === 'active' && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {activeAgents.map((agent) => (
                <Card key={agent.id} glow="magenta">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-bold text-text-white">{agent.name}</h3>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-success-green rounded-full animate-pulse" />
                      <span className="text-success-green text-sm font-medium">{agent.status}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-lg font-bold text-success-green">{agent.pnl}</div>
                      <div className="text-off-white text-sm">P&L</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-accent-cyan">{agent.trades}</div>
                      <div className="text-off-white text-sm">Trades</div>
                    </div>
                  </div>

                  <div className="bg-primary rounded-lg p-3 mb-4">
                    <div className="text-sm text-off-white mb-1">Next Action:</div>
                    <div className="text-text-white font-medium">{agent.nextAction}</div>
                  </div>

                  <div className="flex space-x-2">
                    <Button size="sm" variant="ghost" className="flex-1">
                      <Pause size={16} className="mr-2" />
                      Pause
                    </Button>
                    <Button size="sm" variant="ghost" className="flex-1">
                      <Settings size={16} className="mr-2" />
                      Settings
                    </Button>
                  </div>
                </Card>
              ))}
            </div>

            {/* Performance Chart */}
            <Card>
              <h2 className="text-xl font-bold text-text-white mb-6">Agent Performance</h2>
              <div className="h-64 bg-primary rounded-lg flex items-center justify-center border border-border-gray">
                <div className="text-center">
                  <TrendingUp size={48} className="text-success-green mx-auto mb-4" />
                  <p className="text-off-white">Performance Chart</p>
                  <p className="text-border-gray text-sm">Real-time agent performance metrics</p>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}

export default OmniAgent
