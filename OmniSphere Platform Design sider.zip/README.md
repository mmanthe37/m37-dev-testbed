# OmniSphere Platform

A comprehensive, production-ready digital asset management platform featuring four specialized hubs for NFT management, trading, AI-driven automation, and liquidity provision.

## 🌟 Platform Overview

OmniSphere is a cyber-minimalist, professional-grade platform that combines cutting-edge web3 technologies with AI-powered automation. Built with security, performance, and user experience at its core.

### Platform Hubs

- **🎨 OmniFi**: NFT Management & Digital Content
- **📈 OmniTrade**: Professional Trading Interface  
- **🤖 OmniAgent**: AI-Driven Automated Strategies
- **💧 OmniPool**: Liquidity Provision & Yield Farming

## 🎯 Key Features

### Design System
- **Cyber-Minimalist Aesthetic**: Dark theme with electric cyan (#00FFFF) and magenta (#FF00FF) accents
- **Inter Typography**: Variable font weights for clear visual hierarchy
- **8px Grid System**: Consistent spacing and alignment
- **Responsive Design**: Fluid experience from mobile (360px) to ultra-wide (1920px+)
- **Micro-interactions**: Smooth transitions and hover effects

### Technology Stack
- **Frontend**: React 18 + TypeScript + Tailwind CSS
- **Routing**: React Router (HashRouter for static deployment)
- **Icons**: Lucide React
- **UI Components**: Custom components with shadcn/ui integration
- **Styling**: CSS-in-JS with Tailwind utilities

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

1. **Clone and Setup**
   ```bash
   git clone <repository-url>
   cd omnisphere
   npm install
   ```

2. **Environment Configuration**
   Create a `.env` file in the root directory:
   ```env
   REACT_APP_COINBASE_CLIENT_API_KEY=your_client_api_key
   REACT_APP_API_URL=http://localhost:5000/api
   ```

3. **Start Development Server**
   ```bash
   npm run dev
   ```

4. **Build for Production**
   ```bash
   npm run build
   ```

## 🏗️ Architecture

### Frontend Structure
```
src/
├── components/
│   ├── Navigation.tsx          # Main navigation
│   └── ui/                     # Reusable UI components
│       ├── Card.tsx
│       └── Button.tsx
├── pages/                      # Hub pages
│   ├── Home.tsx               # Landing page
│   ├── OmniFi.tsx             # NFT management
│   ├── OmniTrade.tsx          # Trading interface
│   ├── OmniAgent.tsx          # AI automation
│   └── OmniPool.tsx           # Liquidity pools
├── styles/
│   └── globals.css            # Global styles & CSS variables
└── App.tsx                    # Main app with routing
```

### Design Tokens
```css
:root {
  --primary-bg: #111111;        /* Deep charcoal background */
  --secondary-bg: #1A1A1A;      /* Panel backgrounds */
  --accent-cyan: #00FFFF;       /* Primary actions */
  --accent-magenta: #FF00FF;    /* Secondary actions */
  --text-white: #FFFFFF;        /* Headings */
  --text-off-white: #EAEAEA;    /* Body text */
  --success-green: #00FF7F;     /* Success states */
  --error-red: #FF4136;         /* Error states */
  --border-gray: #2B2B2B;       /* Borders */
}
```

## 🎨 Hub Details

### OmniFi Hub
- **NFT Portfolio Overview**: Total value, 24h changes, collection count
- **Collection Management**: Floor prices, volume tracking, owned NFTs
- **Individual NFT Display**: Detailed views with rarity indicators
- **NFT Creation**: Intuitive minting interface with metadata management

### OmniTrade Hub  
- **Real-time Market Data**: Live price feeds with volume indicators
- **Professional Trading Interface**: Order placement with market/limit options
- **Portfolio Analytics**: P&L tracking, asset allocation, performance metrics
- **Order Book**: Live buy/sell order visualization

### OmniAgent Hub
- **Conversational AI Interface**: Natural language strategy configuration
- **ReAct Loop Implementation**: Reasoning, tool usage, and observation cycle
- **Strategy Marketplace**: Pre-built templates with risk assessments
- **Active Agent Monitoring**: Real-time performance tracking

### OmniPool Hub
- **Liquidity Pool Browser**: Multi-protocol pool discovery
- **Position Management**: Active liquidity tracking with fee earnings
- **Yield Farming**: Automated reward optimization
- **Risk Assessment**: Pool risk levels with APY calculations

## 🛡️ Security Features

### Frontend Security
- **Environment Variables**: Sensitive configs in `.env` files
- **Client API Keys**: Domain-restricted Coinbase client keys
- **Input Validation**: Form validation with proper sanitization
- **Secure Routing**: Protected routes for sensitive operations

### Planned Backend Integration
- **Server-only Operations**: All sensitive blockchain operations on backend
- **API Key Management**: Secure storage of Coinbase Secret and Zerion keys
- **CDP Wallet Integration**: Programmable policies for automated safety
- **Rate Limiting**: API protection with intelligent caching

## 🤖 AI Agent Implementation

### Prompt Engineering Techniques
- **Few-shot Prompting**: Examples for strategy selection
- **Chain of Thought**: Step-by-step reasoning for parameter generation
- **Tool Integration**: Market data fetching and strategy execution
- **Context Awareness**: User profile and market condition integration

### Agent Architecture
```
Model (LLM) → Tools → Orchestration
     ↓           ↓         ↓
  Reasoning → Actions → Observations
```

## 📊 Mock Data Integration

The current implementation uses realistic mock data to demonstrate functionality:

- **Market Data**: Cryptocurrency prices, volumes, and trends
- **NFT Collections**: Simulated NFT portfolios with metadata
- **Trading History**: Realistic transaction logs and P&L
- **Pool Analytics**: DeFi pool statistics and yield farming data

## 🚀 Deployment

### Static Deployment (Recommended)
1. Build the project: `npm run build`
2. Deploy the `dist` folder to any static hosting service
3. Configure environment variables in your hosting platform

### Supported Platforms
- Vercel
- Netlify
- AWS S3 + CloudFront
- GitHub Pages
- Any static hosting service

## 🔮 Roadmap

### Phase 1: Core Platform ✅
- [x] Design system implementation
- [x] Four hub interfaces
- [x] Navigation and routing
- [x] Responsive design

### Phase 2: Backend Integration (Planned)
- [ ] Node.js/Express backend
- [ ] MongoDB with Mongoose
- [ ] Coinbase CDP SDK integration
- [ ] Zerion API integration

### Phase 3: AI Enhancement (Planned)
- [ ] LLM integration for OmniAgent
- [ ] Advanced prompt engineering
- [ ] Strategy backtesting
- [ ] Performance optimization

### Phase 4: Production Features (Planned)
- [ ] User authentication
- [ ] Real-time data feeds
- [ ] Advanced analytics
- [ ] Mobile app

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- **Coinbase Developer Platform**: Web3 infrastructure and tools
- **Zerion**: On-chain data analytics APIs  
- **React**: Frontend framework foundation
- **Tailwind CSS**: Utility-first styling
- **Lucide**: Beautiful icon library

---

**Built with ❤️ for the future of decentralized finance**
