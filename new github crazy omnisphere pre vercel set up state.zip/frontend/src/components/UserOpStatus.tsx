import React from "react";

interface UserOpStatusProps {
  opHash: string;
}

export const UserOpStatus: React.FC<UserOpStatusProps> = ({ opHash }) => {
  if (!opHash) return null;
  return (
    <div className="mt-6 text-accentAqua text-xl">
      UserOp Hash: {opHash}
    </div>
  );
};