import React, { useEffect, useState } from "react";
import { useApi } from "../hooks/useApi";

export default function GaslessStatus({ address }: { address: string }) {
  const api = useApi();
  const [sponsored, setSponsored] = useState(false);
  const [metrics, setMetrics] = useState<any>({ totalSponsored: 0, savedUSD: 0 });

  useEffect(() => {
    (async () => {
      const { data } = await api.get(`/omnitrade/gasless-metrics?address=${address}`);
      setMetrics(data.metrics);
      setSponsored(data.isSponsored);
    })();
  }, [address]);

  return (
    <div className="bg-card rounded-xl shadow-omnisphere p-4 mb-3">
      <div>
        <span className="font-bold text-accentAqua">Gasless:</span>
        <span className={`ml-2 font-bold ${sponsored ? "text-accentGreen" : "text-red-400"}`}>
          {sponsored ? "Sponsored" : "Not Sponsored"}
        </span>
      </div>
      <div className="text-sm text-textSecondary mt-2">
        You’ve saved <span className="text-accentBlue">${metrics.savedUSD.toFixed(2)}</span> in gas fees.
      </div>
    </div>
  );
}