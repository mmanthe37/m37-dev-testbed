import React from "react";

export default function GaslessInfo() {
  return (
    <div className="bg-card rounded-xl shadow-omnisphere p-6 mb-6">
      <h2 className="font-orbitron font-bold text-accentBlue mb-2">Gasless Trading (Paymaster Protocol)</h2>
      <p className="text-textSecondary">
        OmniTrade supports gasless transactions using paymaster protocols. When available, your trades will be executed without requiring ETH for gas, lowering the barrier to DeFi participation.
      </p>
      <ul className="list-disc ml-6 mt-2 text-accentAqua">
        <li>Platform covers gas for supported trades</li>
        <li>Fast, seamless execution</li>
        <li>No need to maintain ETH for fees</li>
      </ul>
    </div>
  );
}